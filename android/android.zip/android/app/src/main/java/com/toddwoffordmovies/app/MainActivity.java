package com.toddwoffordmovies.app;

 import android.content.Intent;
import android.os.Bundle;
import co.boundstate.BranchDeepLinks;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.Plugin;
 import android.content.Context;
 import android.media.AudioManager;
import app.xplatform.capacitor.plugins.AdMob;
import java.util.ArrayList;

public class MainActivity extends BridgeActivity {

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    Context context = getApplicationContext();
    AudioManager audioManager = ((AudioManager)context.getSystemService(Context.AUDIO_SERVICE));
    // Initializes the Bridge
    this.init(savedInstanceState, new ArrayList<Class<? extends Plugin>>() {{
      // Additional plugins you've installed go here
      // Ex: add(TotallyAwesomePlugin.class);
    	 add(BranchDeepLinks.class);
       add(AdMob.class);
    }});
  }

    @Override
  protected void onNewIntent(Intent intent) {
    this.setIntent(intent);
    super.onNewIntent(intent);
  }
}
