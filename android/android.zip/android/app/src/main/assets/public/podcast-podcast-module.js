(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["podcast-podcast-module"],{

/***/ "/pc9":
/*!***************************************************!*\
  !*** ./src/app/podcast/podcast-routing.module.ts ***!
  \***************************************************/
/*! exports provided: PodcastPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PodcastPageRoutingModule", function() { return PodcastPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _podcast_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./podcast.page */ "jDtb");




const routes = [
    {
        path: '',
        component: _podcast_page__WEBPACK_IMPORTED_MODULE_3__["PodcastPage"]
    }
];
let PodcastPageRoutingModule = class PodcastPageRoutingModule {
};
PodcastPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PodcastPageRoutingModule);



/***/ }),

/***/ "J6pq":
/*!*******************************************!*\
  !*** ./src/app/podcast/podcast.page.scss ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-segment {\n  background-color: transparent;\n  box-shadow: 0 2px 3px 0 rgba(0, 0, 0, 0.1);\n  border-radius: 0;\n  margin-top: 10px;\n}\nion-segment ion-segment-button {\n  text-transform: capitalize;\n  min-height: 40px !important;\n  border-radius: 0;\n  color: #000;\n  background-color: transparent;\n}\nion-segment ion-segment-button.segment-button-checked {\n  --indicator-color: transparent !important;\n  --indicator-color-checked: transparent !important;\n  background: transparent;\n  margin-bottom: 0;\n  --indicator-box-shadow:none !important;\n  border-bottom: 2px solid #CDAA64;\n  border-radius: 0;\n  --border-radius: 0;\n  color: var(--ion-color-white);\n  --color-checked: var(--ion-color-white)!important;\n  font-weight: 500;\n}\nion-item {\n  border-radius: 8px;\n  margin-bottom: 15px;\n  --padding-start: 0px;\n  --inner-padding-end: 0px;\n}\nion-item ion-thumbnail {\n  width: 90px;\n  height: 100%;\n  margin: 0px;\n  position: relative;\n}\nion-item ion-thumbnail a {\n  display: block;\n  height: 100%;\n}\nion-item ion-thumbnail a img {\n  height: 90px;\n  object-fit: cover;\n}\nion-item ion-thumbnail a video {\n  height: 90px;\n  object-fit: cover;\n  width: 90px;\n}\nion-item ion-thumbnail [heart] {\n  position: absolute;\n  left: 10px;\n  top: 10px;\n  width: 27px;\n  height: 27px;\n  background: rgba(255, 255, 255, 0.72);\n  border-radius: 50%;\n  text-align: center;\n  line-height: 34px;\n  font-size: 16px;\n  color: #c1c1c1;\n}\nion-item ion-thumbnail [heart][filled] {\n  color: var(--ion-color-orange);\n}\nion-item ion-label {\n  white-space: normal;\n  margin-right: 0px;\n  padding-left: 10px;\n  margin: 0;\n}\nion-item ion-label h2 {\n  margin: 0px;\n  padding-right: 5px;\n  font-size: 14px;\n  color: var(--ion-color-black3);\n  font-weight: 600;\n}\nion-item ion-label h2 a {\n  text-decoration: none;\n  color: var(--ion-color-black3);\n}\nion-item ion-label h2 a:hover {\n  color: #CDAA64;\n}\nion-item ion-label p {\n  margin-top: 5px;\n  padding-right: 5px;\n  line-height: 1.25;\n  font-size: 12px;\n  display: flex;\n}\nion-item ion-label p img {\n  height: 16px;\n  min-width: 14px;\n  margin-right: 5px;\n}\nion-item ion-label p[address] {\n  color: var(--ion-color-black4);\n}\nion-item ion-label p[address] ion-icon {\n  font-size: 13px;\n  position: relative;\n  top: 2px;\n  color: #CDAA64;\n}\nion-item ion-label p[category] {\n  align-items: center;\n  color: var(--ion-color-grey4);\n}\nion-item ion-label p[category] a {\n  text-decoration: none;\n}\nion-item ion-label p[category] a span {\n  background-color: #8c2828;\n  color: #fff;\n  display: block;\n  padding: 2px 5px 3px;\n  font-size: 11px;\n  margin-right: 2px;\n  transition: all 0.3s;\n}\nion-item ion-label p[category] a:hover span {\n  background-color: #000;\n}\nion-item ion-label p[category] .liststar {\n  background-color: transparent;\n  padding: 0;\n  margin-left: auto;\n}\nion-item ion-label p[category] .liststar ion-icon {\n  color: #FFA619;\n  font-size: 13px;\n  padding: 0px 1px;\n}\nion-item [salary-apply] {\n  margin-top: 5px;\n}\nion-item [salary-apply] ion-col {\n  padding: 0px;\n}\nion-item [salary-apply] ion-badge {\n  margin-top: 5px;\n  background: var(--ion-color-ltblue);\n  color: var(--ion-color-primary);\n  padding: 4px 10px;\n  font-size: 12px;\n  font-weight: 500;\n  border-radius: 30px;\n}\nion-item [salary-apply] ion-button {\n  margin-bottom: 0px;\n  font-size: 11px;\n  margin-right: 0px;\n  float: right;\n  --background: var(--ion-color-bggradient);\n  text-transform: capitalize;\n  --border-radius: 30px 0px 0px 30px;\n}\n.filtericon {\n  font-size: 32px;\n  border: 1px solid #ececec;\n  padding: 6px 7px;\n  position: relative;\n  top: 12px;\n  border-radius: 6px;\n  color: #8c2828;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXHBvZGNhc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsNkJBQUE7RUFDQSwwQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7QUFDRjtBQUFFO0VBQ0UsMEJBQUE7RUFDQywyQkFBQTtFQUNDLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLDZCQUFBO0FBRU47QUFETTtFQUNFLHlDQUFBO0VBQ0EsaURBQUE7RUFDQSx1QkFBQTtFQUNBLGdCQUFBO0VBQ0Esc0NBQUE7RUFDQSxnQ0FBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSw2QkFBQTtFQUNBLGlEQUFBO0VBQ0EsZ0JBQUE7QUFHUjtBQUVBO0VBQ0Usa0JBQUE7RUFDQSxtQkFBQTtFQUNBLG9CQUFBO0VBQ0Esd0JBQUE7QUFDRjtBQUFFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7QUFFSjtBQURJO0VBQ0UsY0FBQTtFQUNBLFlBQUE7QUFHTjtBQUZNO0VBQ0UsWUFBQTtFQUNBLGlCQUFBO0FBSVI7QUFGTTtFQUNDLFlBQUE7RUFDQyxpQkFBQTtFQUNBLFdBQUE7QUFJUjtBQURJO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EscUNBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtBQUdOO0FBRk07RUFDRSw4QkFBQTtBQUlSO0FBQUU7RUFDRSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0FBRUo7QUFESTtFQUNFLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSw4QkFBQTtFQUNBLGdCQUFBO0FBR047QUFGTTtFQUNFLHFCQUFBO0VBQ0EsOEJBQUE7QUFJUjtBQUhRO0VBQ0UsY0FBQTtBQUtWO0FBREk7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxhQUFBO0FBR047QUFGTTtFQUNFLFlBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUFJUjtBQURNO0VBQ0UsOEJBQUE7QUFHUjtBQUZRO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLGNBQUE7QUFJVjtBQURNO0VBQ0UsbUJBQUE7RUFDQSw2QkFBQTtBQUdSO0FBRlE7RUFDRSxxQkFBQTtBQUlWO0FBSFU7RUFDRSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxjQUFBO0VBQ0Esb0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxvQkFBQTtBQUtaO0FBRlk7RUFDRSxzQkFBQTtBQUlkO0FBRVE7RUFFRSw2QkFBQTtFQUNBLFVBQUE7RUFDQSxpQkFBQTtBQURWO0FBRVU7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBQVo7QUFNRTtFQUNFLGVBQUE7QUFKSjtBQUtJO0VBQ0UsWUFBQTtBQUhOO0FBS0k7RUFDRSxlQUFBO0VBQ0EsbUNBQUE7RUFDQSwrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUFITjtBQUtJO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EseUNBQUE7RUFDQSwwQkFBQTtFQUNBLGtDQUFBO0FBSE47QUFRQTtFQUNFLGVBQUE7RUFDQSx5QkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FBTEYiLCJmaWxlIjoicG9kY2FzdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tc2VnbWVudCB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgYm94LXNoYWRvdzogMCAycHggM3B4IDAgcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG4gIGJvcmRlci1yYWRpdXM6IDA7XHJcbiAgbWFyZ2luLXRvcDogMTBweDtcclxuICBpb24tc2VnbWVudC1idXR0b257XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogY2FwaXRhbGl6ZTtcclxuXHQgICAgbWluLWhlaWdodDogNDBweCFpbXBvcnRhbnQ7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDA7XHJcbiAgICAgIGNvbG9yOiAjMDAwO1xyXG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgJi5zZWdtZW50LWJ1dHRvbi1jaGVja2Vke1xyXG4gICAgICAgIC0taW5kaWNhdG9yLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG4gICAgICAgIC0taW5kaWNhdG9yLWNvbG9yLWNoZWNrZWQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMDtcclxuICAgICAgICAtLWluZGljYXRvci1ib3gtc2hhZG93Om5vbmUgIWltcG9ydGFudDtcclxuICAgICAgICBib3JkZXItYm90dG9tOiAycHggc29saWQgI0NEQUE2NDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAwO1xyXG4gICAgICAgIC0tYm9yZGVyLXJhZGl1czogMDtcclxuICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgICAgICAtLWNvbG9yLWNoZWNrZWQ6IHZhcigtLWlvbi1jb2xvci13aGl0ZSkhaW1wb3J0YW50O1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgIH1cclxuICB9XHJcbn1cclxuXHJcbmlvbi1pdGVtIHtcclxuICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxuICAtLXBhZGRpbmctc3RhcnQ6IDBweDtcclxuICAtLWlubmVyLXBhZGRpbmctZW5kOiAwcHg7XHJcbiAgaW9uLXRodW1ibmFpbCB7XHJcbiAgICB3aWR0aDogOTBweDtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIG1hcmdpbjogMHB4O1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgYXtcclxuICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgaW1ne1xyXG4gICAgICAgIGhlaWdodDogOTBweDtcclxuICAgICAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICAgICAgfVxyXG4gICAgICB2aWRlb3tcclxuICAgICAgIGhlaWdodDogOTBweDtcclxuICAgICAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICAgICAgICB3aWR0aDogOTBweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgW2hlYXJ0XSB7XHJcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgbGVmdDogMTBweDtcclxuICAgICAgdG9wOiAxMHB4O1xyXG4gICAgICB3aWR0aDogMjdweDtcclxuICAgICAgaGVpZ2h0OiAyN3B4O1xyXG4gICAgICBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNzIpO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgbGluZS1oZWlnaHQ6IDM0cHg7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgY29sb3I6ICNjMWMxYzE7XHJcbiAgICAgICZbZmlsbGVkXSB7XHJcbiAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1vcmFuZ2UpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIGlvbi1sYWJlbCB7XHJcbiAgICB3aGl0ZS1zcGFjZTogbm9ybWFsO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAwcHg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgICBoMiB7XHJcbiAgICAgIG1hcmdpbjogMHB4O1xyXG4gICAgICBwYWRkaW5nLXJpZ2h0OiA1cHg7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1ibGFjazMpO1xyXG4gICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICBhe1xyXG4gICAgICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWJsYWNrMyk7XHJcbiAgICAgICAgJjpob3ZlcntcclxuICAgICAgICAgIGNvbG9yOiAjQ0RBQTY0O1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcCB7XHJcbiAgICAgIG1hcmdpbi10b3A6IDVweDtcclxuICAgICAgcGFkZGluZy1yaWdodDogNXB4O1xyXG4gICAgICBsaW5lLWhlaWdodDogMS4yNTtcclxuICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICBpbWcge1xyXG4gICAgICAgIGhlaWdodDogMTZweDtcclxuICAgICAgICBtaW4td2lkdGg6IDE0cHg7XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiA1cHg7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgICZbYWRkcmVzc10ge1xyXG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItYmxhY2s0KTtcclxuICAgICAgICBpb24taWNvbntcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICAgIHRvcDogMnB4O1xyXG4gICAgICAgICAgY29sb3I6ICNDREFBNjQ7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgICZbY2F0ZWdvcnldIHtcclxuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZ3JleTQpO1xyXG4gICAgICAgIGF7XHJcbiAgICAgICAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICAgICAgICBzcGFue1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjOGMyODI4O1xyXG4gICAgICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDJweCA1cHggM3B4O1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDExcHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMnB4O1xyXG4gICAgICAgICAgICB0cmFuc2l0aW9uOiBhbGwgMC4zcztcclxuICAgICAgICAgIH1cclxuICAgICAgICAgICY6aG92ZXJ7XHJcbiAgICAgICAgICAgIHNwYW57XHJcbiAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzAwMDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5saXN0c3RhclxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6dHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgICBwYWRkaW5nOjA7XHJcbiAgICAgICAgICBtYXJnaW4tbGVmdDogYXV0bztcclxuICAgICAgICAgIGlvbi1pY29ue1xyXG4gICAgICAgICAgICBjb2xvcjogI0ZGQTYxOTtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwcHggMXB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICBbc2FsYXJ5LWFwcGx5XSB7XHJcbiAgICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgICBpb24tY29sIHtcclxuICAgICAgcGFkZGluZzogMHB4O1xyXG4gICAgfVxyXG4gICAgaW9uLWJhZGdlIHtcclxuICAgICAgbWFyZ2luLXRvcDogNXB4O1xyXG4gICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItbHRibHVlKTtcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAgICAgcGFkZGluZzogNHB4IDEwcHg7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgIH1cclxuICAgIGlvbi1idXR0b24ge1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTFweDtcclxuICAgICAgbWFyZ2luLXJpZ2h0OiAwcHg7XHJcbiAgICAgIGZsb2F0OiByaWdodDtcclxuICAgICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItYmdncmFkaWVudCk7XHJcbiAgICAgIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xyXG4gICAgICAtLWJvcmRlci1yYWRpdXM6IDMwcHggMHB4IDBweCAzMHB4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuLmZpbHRlcmljb24ge1xyXG4gIGZvbnQtc2l6ZTogMzJweDtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjZWNlY2VjO1xyXG4gIHBhZGRpbmc6IDZweCA3cHg7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHRvcDogMTJweDtcclxuICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgY29sb3I6ICM4YzI4Mjg7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ "ZeBp":
/*!*******************************************!*\
  !*** ./src/app/podcast/podcast.module.ts ***!
  \*******************************************/
/*! exports provided: PodcastPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PodcastPageModule", function() { return PodcastPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../shared/shared.module */ "PCNd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _podcast_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./podcast-routing.module */ "/pc9");
/* harmony import */ var _podcast_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./podcast.page */ "jDtb");
/* harmony import */ var ngx_stars__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ngx-stars */ "t10x");
/* harmony import */ var ng2_search_filter__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ng2-search-filter */ "cZdB");










let PodcastPageModule = class PodcastPageModule {
};
PodcastPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__["SharedModule"],
            ngx_stars__WEBPACK_IMPORTED_MODULE_8__["NgxStarsModule"],
            ng2_search_filter__WEBPACK_IMPORTED_MODULE_9__["Ng2SearchPipeModule"],
            _podcast_routing_module__WEBPACK_IMPORTED_MODULE_6__["PodcastPageRoutingModule"]
        ],
        declarations: [_podcast_page__WEBPACK_IMPORTED_MODULE_7__["PodcastPage"]]
    })
], PodcastPageModule);



/***/ }),

/***/ "hQvj":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/podcast/podcast.page.html ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"py-2\" lines=\"none\">\n    <ion-menu-button slot=\"start\">\n      <ion-icon name=\"menu-outline\"></ion-icon>\n    </ion-menu-button>\n    <ion-title>Podcast</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-row class=\"mb-2\">\n    <ion-col>\n      <ion-searchbar [(ngModel)]=\"filterTerm\"></ion-searchbar>\n    </ion-col>\n  </ion-row>\n\n  <ion-grid>\n    <ion-row *ngFor=\"let data of content | filter:filterTerm \" routerLink=\"/podcastdetails/{{data?.id}}\">\n      <ion-item lines=\"none\" >\n        <ion-thumbnail>\n          <a >\n            <!-- <img src=\"assets/images/vpost.png\"/> -->\n             <img *ngIf=\"errors.indexOf(data?.video) >= 0 && errors.indexOf(data?.youtube_link) >= 0 \" src=\"assets/images/dummy.png\"  alt=\"\"/> \n      <video *ngIf=\"errors.indexOf(data?.video) == -1 && data?.video_type == 'video'\" src=\"{{IMAGES_URL+'/'+data?.video}}\"  alt=\"\">  </video> \n            <img  *ngIf=\"errors.indexOf(data?.youtube_link) == -1 && data?.video_type == 'link'\" src=\"{{data.thumbnail}}\"/>  \n          </a>\n            <!-- <span heart filled>\n              <ion-icon name=\"heart\"></ion-icon>\n            </span> -->\n        </ion-thumbnail>\n        <ion-label>\n            <h2><a >{{data?.title}}</a></h2>\n            <p address><span><ion-icon name=\"time-outline\"></ion-icon> {{data?.dates}}</span></p>\n            <!-- <p address><span [innerHTML]=\"data?.description\"></span></p> -->\n            \n            <p class=\"mt-0\" category>\n              <span class=\"liststar\">\n                 <ngx-stars  [size]='1' [readonly]=\"true\" [initialStars]=\"data?.rating\" [maxStars]=\"5\" [color]=\"'#f90'\"></ngx-stars>\n              </span>\n            </p>\n        </ion-label>\n      </ion-item>\n\n      <!-- <ion-item lines=\"none\">\n        <ion-thumbnail>\n          <a routerLink=\"/podcastdetails\"><img src=\"assets/images/ypost.png\"/></a>\n            \n        </ion-thumbnail>\n        <ion-label>\n            <h2><a routerLink=\"/podcastdetails\">The Broken Hearts Gallery (2020)</a></h2>\n            <p address><span><ion-icon name=\"time-outline\"></ion-icon> February 26, 2021</span></p>\n            <p address><span>The Broken Hearts Gallery is an above average romantic comedy, perfect for any date night. It...</span></p>\n            <p class=\"mt-0\" category>\n              <span class=\"liststar\">\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star-outline\"></ion-icon>\n              </span>\n            </p>\n        </ion-label>\n      </ion-item>\n\n      <ion-item lines=\"none\">\n        <ion-thumbnail>\n          <a routerLink=\"/podcastdetails\"><img src=\"assets/images/vpost.png\"/></a>\n           \n        </ion-thumbnail>\n        <ion-label>\n            <h2><a routerLink=\"/podcastdetails\">The Broken Hearts Gallery (2020)</a></h2>\n            <p address><span><ion-icon name=\"time-outline\"></ion-icon> February 26, 2021</span></p>\n            <p address><span>The Broken Hearts Gallery is an above average romantic comedy, perfect for any date night. It...</span></p>\n            <p class=\"mt-0\" category>\n              <span class=\"liststar\">\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star-outline\"></ion-icon>\n              </span>\n            </p>\n        </ion-label>\n      </ion-item>\n\n      <ion-item lines=\"none\">\n        <ion-thumbnail>\n          <a routerLink=\"/podcastdetails\"><img src=\"assets/images/ypost.png\"/></a>\n            \n        </ion-thumbnail>\n        <ion-label>\n            <h2><a routerLink=\"/podcastdetails\">The Broken Hearts Gallery (2020)</a></h2>\n            <p address><span><ion-icon name=\"time-outline\"></ion-icon> February 26, 2021</span></p>\n            <p address><span>The Broken Hearts Gallery is an above average romantic comedy, perfect for any date night. It...</span></p>\n            <p class=\"mt-0\" category>\n              <span class=\"liststar\">\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star-outline\"></ion-icon>\n              </span>\n            </p>\n        </ion-label>\n      </ion-item>\n\n      <ion-item lines=\"none\">\n        <ion-thumbnail>\n          <a routerLink=\"/podcastdetails\"><img src=\"assets/images/vpost.png\"/></a>\n           \n        </ion-thumbnail>\n        <ion-label>\n            <h2><a routerLink=\"/podcastdetails\">The Broken Hearts Gallery (2020)</a></h2>\n            <p address><span><ion-icon name=\"time-outline\"></ion-icon> February 26, 2021</span></p>\n            <p address><span>The Broken Hearts Gallery is an above average romantic comedy, perfect for any date night. It...</span></p>\n            <p class=\"mt-0\" category>\n              <span class=\"liststar\">\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star-outline\"></ion-icon>\n              </span>\n            </p>\n        </ion-label>\n      </ion-item> -->\n    </ion-row>\n  </ion-grid>\n <ion-infinite-scroll *ngIf=\"is_more_records\" (ionInfinite)=\"doInfinite($event)\">\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"Loading more data...\">\n    </ion-infinite-scroll-content>\n  </ion-infinite-scroll>\n  <app-subscribeslider></app-subscribeslider>\n\n</ion-content>\n");

/***/ }),

/***/ "jDtb":
/*!*****************************************!*\
  !*** ./src/app/podcast/podcast.page.ts ***!
  \*****************************************/
/*! exports provided: PodcastPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PodcastPage", function() { return PodcastPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_podcast_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./podcast.page.html */ "hQvj");
/* harmony import */ var _podcast_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./podcast.page.scss */ "J6pq");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../config */ "Vx+w");
/* harmony import */ var _services_user_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/user/user.service */ "CFL1");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _services_event_event_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../services/event/event.service */ "gcxx");








let PodcastPage = class PodcastPage {
    constructor(events1, router, userService, ref, activatedRoute) {
        this.events1 = events1;
        this.router = router;
        this.userService = userService;
        this.ref = ref;
        this.activatedRoute = activatedRoute;
        this.win = window;
        this.errors = ['', null, undefined];
        this.is_submit = false;
        this.IMAGES_URL = _config__WEBPACK_IMPORTED_MODULE_4__["config"].IMAGES_URL;
        this.is_loaded = false;
        this.content = [];
        this.mdata = [];
        this.is_more_records = true;
        this.limit = 40;
        this.page_number = 0;
        this.truncating = true;
        this.allowedMimes = _config__WEBPACK_IMPORTED_MODULE_4__["config"].IMAGE_EXTENSIONS;
    }
    ngOnInit() {
        this.viewdata(false, "");
    }
    viewdata(isFirstLoad, event) {
        // this.userService.presentLoading();
        this.userService.postData({ page_no: this.page_number }, 'view_allpodcasts').subscribe((result) => {
            this.userService.stopLoading();
            if (this.errors.indexOf(result.result) == -1) {
                this.is_loaded = true;
                // this.content = result.result;
                this.mdata = result.result;
                for (let i = 0; i < this.mdata.length; i++) {
                    this.content.push(this.mdata[i]);
                }
                console.log(this.content.length);
                console.log(result.total);
                if (this.content.length == result.total) {
                    this.is_more_records = false;
                }
                if (isFirstLoad)
                    event.target.complete();
                this.page_number++;
            }
            else {
                this.userService.presentToast('Error while fetch results! Please try after some time.', 'danger');
            }
        }, err => {
            this.is_loaded = true;
            this.userService.stopLoading();
            this.userService.presentToast('Unable to fetch results, Please try again', 'danger');
        });
    }
    doInfinite(event) {
        this.viewdata(true, event);
    }
};
PodcastPage.ctorParameters = () => [
    { type: _services_event_event_service__WEBPACK_IMPORTED_MODULE_7__["EventService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _services_user_user_service__WEBPACK_IMPORTED_MODULE_5__["UserService"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectorRef"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"] }
];
PodcastPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-podcast',
        template: _raw_loader_podcast_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_podcast_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PodcastPage);



/***/ })

}]);
//# sourceMappingURL=podcast-podcast-module.js.map