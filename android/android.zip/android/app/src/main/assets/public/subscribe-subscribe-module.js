(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["subscribe-subscribe-module"],{

/***/ "1Ijd":
/*!*********************************************!*\
  !*** ./src/app/subscribe/subscribe.page.ts ***!
  \*********************************************/
/*! exports provided: SubscribePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubscribePage", function() { return SubscribePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_subscribe_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./subscribe.page.html */ "uL3U");
/* harmony import */ var _subscribe_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./subscribe.page.scss */ "ay4+");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _services_user_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/user/user.service */ "CFL1");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _services_event_event_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/event/event.service */ "gcxx");







let SubscribePage = class SubscribePage {
    constructor(events1, router, userService, ref, activatedRoute) {
        this.events1 = events1;
        this.router = router;
        this.userService = userService;
        this.ref = ref;
        this.activatedRoute = activatedRoute;
        this.errors = ['', null, undefined, false];
        this.is_submit = false;
        this.is_loaded = false;
        this.reg_exp = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    }
    ngOnInit() {
    }
    submit() {
        this.is_submit = true;
        if (this.errors.indexOf(this.email) >= 0 || !this.reg_exp.test(String(this.email).toLowerCase()) || this.errors.indexOf(this.first_name) >= 0 || this.errors.indexOf(this.last_name) >= 0) {
            return false;
        }
        this.userService.presentLoading();
        var dict = {
            first_name: this.first_name,
            last_name: this.last_name,
            email: this.email
        };
        this.userService.postData(dict, 'add_subscribe').subscribe((result) => {
            this.userService.stopLoading();
            if (result.status == 1) {
                this.userService.presentToast('Subscribe successfully.', 'success');
                this.router.navigate(['/home']);
            }
            else {
                this.userService.stopLoading();
                this.userService.presentToast('Error while performing action! Please try after some time.', 'danger');
            }
        }, err => {
            this.userService.stopLoading();
            this.userService.presentToast('Unable to performing action, Please try after some time.', 'danger');
        });
    }
};
SubscribePage.ctorParameters = () => [
    { type: _services_event_event_service__WEBPACK_IMPORTED_MODULE_6__["EventService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _services_user_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectorRef"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] }
];
SubscribePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-subscribe',
        template: _raw_loader_subscribe_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_subscribe_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SubscribePage);



/***/ }),

/***/ "Gj2j":
/*!***********************************************!*\
  !*** ./src/app/subscribe/subscribe.module.ts ***!
  \***********************************************/
/*! exports provided: SubscribePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubscribePageModule", function() { return SubscribePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _subscribe_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./subscribe-routing.module */ "Royt");
/* harmony import */ var _subscribe_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./subscribe.page */ "1Ijd");







let SubscribePageModule = class SubscribePageModule {
};
SubscribePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _subscribe_routing_module__WEBPACK_IMPORTED_MODULE_5__["SubscribePageRoutingModule"]
        ],
        declarations: [_subscribe_page__WEBPACK_IMPORTED_MODULE_6__["SubscribePage"]]
    })
], SubscribePageModule);



/***/ }),

/***/ "Royt":
/*!*******************************************************!*\
  !*** ./src/app/subscribe/subscribe-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: SubscribePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubscribePageRoutingModule", function() { return SubscribePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _subscribe_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./subscribe.page */ "1Ijd");




const routes = [
    {
        path: '',
        component: _subscribe_page__WEBPACK_IMPORTED_MODULE_3__["SubscribePage"]
    }
];
let SubscribePageRoutingModule = class SubscribePageRoutingModule {
};
SubscribePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SubscribePageRoutingModule);



/***/ }),

/***/ "ay4+":
/*!***********************************************!*\
  !*** ./src/app/subscribe/subscribe.page.scss ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("h1 {\n  font-size: 22px;\n  margin-bottom: 15px;\n}\n\nion-button {\n  --border-radius: 6px;\n}\n\nion-item {\n  --padding-start:0px;\n  --min-height: 30px;\n  --inner-padding-end: 0;\n  border: 1px solid #ececec;\n  border-radius: 6px;\n}\n\nion-item ion-icon {\n  position: relative;\n  left: 13px;\n  color: #8c2828;\n  font-size: 20px;\n}\n\nion-item ion-input {\n  --padding-top: 8px;\n  --padding-bottom: 8px;\n  --padding-end: 0;\n  --padding-start: 25px;\n}\n\nform ion-label {\n  margin-bottom: 5px;\n  display: block;\n  font-size: 14px;\n  color: var(--ion-color-primary);\n}\n\n.subbox {\n  padding: 20px;\n  border: 1px solid #f1f1f1;\n  margin: 10px;\n  border-radius: 6px;\n}\n\n.subicon {\n  text-align: center;\n  margin: 0 auto;\n  display: block;\n  border-radius: 100px;\n  padding: 17px;\n  font-size: 50px;\n  margin-bottom: 14px;\n  border: 1px solid #ececec;\n  background-color: #000;\n  color: #fff;\n}\n\n[error] {\n  color: #ff0000;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXHN1YnNjcmliZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxlQUFBO0VBQ0EsbUJBQUE7QUFDRjs7QUFFQTtFQUNFLG9CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0FBQ0Y7O0FBQ0U7RUFDRSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQUNKOztBQUVFO0VBQ0Usa0JBQUE7RUFDQSxxQkFBQTtFQUNBLGdCQUFBO0VBQ0EscUJBQUE7QUFBSjs7QUFNRTtFQUNFLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSwrQkFBQTtBQUhKOztBQU9BO0VBRUUsYUFBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FBTEY7O0FBUUE7RUFFRSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxjQUFBO0VBQ0Esb0JBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxzQkFBQTtFQUNBLFdBQUE7QUFORjs7QUFRQTtFQUNFLGNBQUE7QUFMRiIsImZpbGUiOiJzdWJzY3JpYmUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaDF7XHJcbiAgZm9udC1zaXplOiAyMnB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbn1cclxuXHJcbmlvbi1idXR0b257XHJcbiAgLS1ib3JkZXItcmFkaXVzOiA2cHg7XHJcbn1cclxuXHJcbmlvbi1pdGVte1xyXG4gIC0tcGFkZGluZy1zdGFydDowcHg7XHJcbiAgLS1taW4taGVpZ2h0OiAzMHB4O1xyXG4gIC0taW5uZXItcGFkZGluZy1lbmQ6IDA7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2VjZWNlYztcclxuICBib3JkZXItcmFkaXVzOiA2cHg7XHJcblxyXG4gIGlvbi1pY29ue1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgbGVmdDogMTNweDtcclxuICAgIGNvbG9yOiAjOGMyODI4O1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gIH1cclxuXHJcbiAgaW9uLWlucHV0e1xyXG4gICAgLS1wYWRkaW5nLXRvcDogOHB4O1xyXG4gICAgLS1wYWRkaW5nLWJvdHRvbTogOHB4O1xyXG4gICAgLS1wYWRkaW5nLWVuZDogMDtcclxuICAgIC0tcGFkZGluZy1zdGFydDogMjVweDtcclxuICB9XHJcbn1cclxuXHJcbmZvcm1cclxue1xyXG4gIGlvbi1sYWJlbHtcclxuICAgIG1hcmdpbi1ib3R0b206IDVweDtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICB9XHJcbn1cclxuXHJcbi5zdWJib3hcclxue1xyXG4gIHBhZGRpbmc6IDIwcHg7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2YxZjFmMTtcclxuICBtYXJnaW46IDEwcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG59XHJcblxyXG4uc3ViaWNvblxyXG57XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwMHB4O1xyXG4gIHBhZGRpbmc6IDE3cHg7XHJcbiAgZm9udC1zaXplOiA1MHB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDE0cHg7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2VjZWNlYztcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAwO1xyXG4gIGNvbG9yOiAjZmZmO1xyXG59XHJcbltlcnJvcl17XHJcbiAgY29sb3I6I2ZmMDAwMDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "uL3U":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/subscribe/subscribe.page.html ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"py-2\" lines=\"none\">\n    <ion-menu-button slot=\"start\">\n      <ion-icon name=\"menu-outline\"></ion-icon>\n    </ion-menu-button>\n    <ion-title>Subscribe</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid class=\"h-100\">\n    <ion-row class=\"h-100 ion-align-items-center\">\n      <ion-col class=\"subbox\">\n        <ion-icon class=\"subicon\" name=\"mail-outline\"></ion-icon>\n                 <div class=\"mb-3 fbox\">\n            <ion-label>Email</ion-label>\n            <ion-item lines=\"none\">\n              <ion-icon name=\"mail-outline\"></ion-icon>\n              <ion-input type=\"email\" [(ngModel)]=\"email\"></ion-input>\n            </ion-item>\n            <span error *ngIf=\"errors.indexOf(email) >= 0 && is_submit == true\">Please enter your email address</span>\n    <span error *ngIf=\"errors.indexOf(email) == -1 && is_submit == true && !reg_exp.test(email.toLowerCase())\">Please enter valid email address</span>\n          </div>\n          <div class=\"mb-3 fbox\">\n            <ion-label>First Name</ion-label>\n            <ion-item lines=\"none\">\n              <ion-icon name=\"person-outline\"></ion-icon>\n              <ion-input type=\"text\" [(ngModel)]=\"first_name\"></ion-input>\n            </ion-item>\n            <span error *ngIf=\"errors.indexOf(first_name) >= 0 && is_submit == true\">Please enter your first name</span>\n          </div>\n          <div class=\"fbox\">\n            <ion-label>Last Name</ion-label>\n            <ion-item lines=\"none\">\n              <ion-icon name=\"person-outline\"></ion-icon>\n              <ion-input type=\"text\" [(ngModel)]=\"last_name\"></ion-input>\n            </ion-item>\n            <span error *ngIf=\"errors.indexOf(last_name) >= 0 && is_submit == true\">Please enter your last name</span>\n          </div>\n          <ion-button class=\"mt-3\" ion-button type=\"submit\" block (click)=\"submit()\">Subscribe</ion-button>\n    \n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=subscribe-subscribe-module.js.map