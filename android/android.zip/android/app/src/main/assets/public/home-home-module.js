(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "A3+G":
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/*! exports provided: HomePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function() { return HomePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./home.page */ "zpKS");




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"]
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], HomePageRoutingModule);



/***/ }),

/***/ "WcN3":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"py-2\" lines=\"none\">\n    <ion-menu-button slot=\"start\">\n      <ion-icon name=\"menu-outline\"></ion-icon>\n    </ion-menu-button>\n    <ion-title>Home</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-row class=\"mb-3\"> \n    <ion-col size=\"10\">\n      <ion-searchbar [(ngModel)]=\"filterTerm\"></ion-searchbar>\n    </ion-col>\n    <ion-col size=\"2\" (click)=\"presentModal()\">\n      <ion-icon  name=\"filter-outline\" class=\"filtericon\"></ion-icon> \n    </ion-col>\n  </ion-row>\n\n  <ion-grid>\n    <ion-row *ngFor=\"let data of content | filter:filterTerm \" routerLink=\"/moviedetails/{{data?.id}}\">\n      <ion-item lines=\"none\" >\n        <ion-thumbnail>\n            <a >\n              <!-- <img src=\"assets/images/post.jpg\"/> -->\n              <img *ngIf=\"errors.indexOf(data.image) >= 0\" src=\"assets/images/dummy.png\"/> \n<img *ngIf=\"errors.indexOf(data.image) == -1\" src=\"{{ IMAGES_URL+'/'+data.image }}\"/>\n            </a>\n            <!-- <span heart filled>\n              <ion-icon name=\"heart\"></ion-icon>\n            </span> -->\n        </ion-thumbnail>\n        <ion-label>\n            <p class=\"mt-0\" category >\n              <a ><span>{{data?.category}}</span></a>\n              <span class=\"liststar\">\n               <ngx-stars  [size]='1' [readonly]=\"true\" [initialStars]=\"data?.rating\" [maxStars]=\"5\" [color]=\"'#f90'\"></ngx-stars>\n              </span>\n            </p>\n            <h2><a >{{data?.title}}</a></h2>\n            <p address><span><ion-icon name=\"time-outline\"></ion-icon> {{data?.dates}}</span></p>\n            <!-- <p address><span [innerHTML]=\"data?.description\"></span></p> -->\n        </ion-label>\n        \n      </ion-item>\n\n     <!--  <ion-item lines=\"none\">\n        <ion-thumbnail>\n          <a routerLink=\"/moviedetails\"><img src=\"assets/images/post1.jpg\"/></a>\n            \n        </ion-thumbnail>\n        <ion-label>\n            <p class=\"mt-0\" category>\n              <a routerLink=\"/moviedetails\"><span>The Latest</span></a>\n              <span class=\"liststar\">\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star-outline\"></ion-icon>\n              </span>\n            </p>\n            <h2><a routerLink=\"/moviedetails\">Greenland (2020)</a></h2>\n            <p address><span><ion-icon name=\"time-outline\"></ion-icon> FEBRUARY 25, 2021</span></p>\n            <p address><span>Waugh and company combine an intelligent script and a refreshing sense of realism to do exactly...</span></p>\n        </ion-label>\n      </ion-item>\n\n      <ion-item lines=\"none\">\n        <ion-thumbnail>\n          <a routerLink=\"/moviedetails\"><img src=\"assets/images/post.jpg\"/></a>\n            \n        </ion-thumbnail>\n        <ion-label>\n            <p class=\"mt-0\" category>\n              <a routerLink=\"/moviedetails\"><span>The Archive</span></a>\n              <span class=\"liststar\">\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star-outline\"></ion-icon>\n              </span>\n            </p>\n            <h2><a routerLink=\"/moviedetails\">The Broken Hearts Gallery (2020)</a></h2>\n            <p address><span><ion-icon name=\"time-outline\"></ion-icon> February 26, 2021</span></p>\n            <p address><span>The Broken Hearts Gallery is an above average romantic comedy, perfect for any date night. It...</span></p>\n        </ion-label>\n      </ion-item>\n\n      <ion-item lines=\"none\">\n        <ion-thumbnail>\n          <a routerLink=\"/moviedetails\"><img src=\"assets/images/post1.jpg\"/></a>\n           \n        </ion-thumbnail>\n        <ion-label>\n            <p class=\"mt-0\" category>\n              <a routerLink=\"/moviedetails\"><span>The Latest</span></a>\n              <span class=\"liststar\">\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star-outline\"></ion-icon>\n              </span>\n            </p>\n            <h2><a routerLink=\"/moviedetails\">Greenland (2020)</a></h2>\n            <p address><span><ion-icon name=\"time-outline\"></ion-icon> FEBRUARY 25, 2021</span></p>\n            <p address><span>Waugh and company combine an intelligent script and a refreshing sense of realism to do exactly...</span></p>\n        </ion-label>\n      </ion-item>\n\n      <ion-item lines=\"none\">\n        <ion-thumbnail>\n          <a routerLink=\"/moviedetails\"><img src=\"assets/images/post.jpg\"/></a>\n           \n        </ion-thumbnail>\n        <ion-label>\n            <p class=\"mt-0\" category>\n              <a routerLink=\"/moviedetails\"><span>The Archive</span></a>\n              <span class=\"liststar\">\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star-outline\"></ion-icon>\n              </span>\n            </p>\n            <h2><a routerLink=\"/moviedetails\">The Broken Hearts Gallery (2020)</a></h2>\n            <p address><span><ion-icon name=\"time-outline\"></ion-icon> February 26, 2021</span></p>\n            <p address><span>The Broken Hearts Gallery is an above average romantic comedy, perfect for any date night. It...</span></p>\n        </ion-label>\n      </ion-item>\n\n      <ion-item lines=\"none\">\n        <ion-thumbnail>\n          <a routerLink=\"/moviedetails\"><img src=\"assets/images/post1.jpg\"/></a>\n          \n        </ion-thumbnail>\n        <ion-label>\n            <p class=\"mt-0\" category>\n              <a routerLink=\"/moviedetails\"><span>The Latest</span></a>\n              <span class=\"liststar\">\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star-outline\"></ion-icon>\n              </span>\n            </p>\n            <h2><a routerLink=\"/moviedetails\">Greenland (2020)</a></h2>\n            <p address><span><ion-icon name=\"time-outline\"></ion-icon> FEBRUARY 25, 2021</span></p>\n            <p address><span>Waugh and company combine an intelligent script and a refreshing sense of realism to do exactly...</span></p>\n        </ion-label>\n      </ion-item> -->\n    </ion-row>\n  </ion-grid>\n  <ion-infinite-scroll *ngIf=\"is_more_records_v\" (ionInfinite)=\"doInfinite1($event)\">\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"Loading more data...\">\n    </ion-infinite-scroll-content>\n  </ion-infinite-scroll>\n  <ion-infinite-scroll *ngIf=\"is_more_records\" (ionInfinite)=\"doInfinite($event)\">\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"Loading more data...\">\n    </ion-infinite-scroll-content>\n  </ion-infinite-scroll>\n<div style=\"text-align: center;background: #ccc;padding: 15px;\" *ngIf=\"content == '' && is_loaded == true\" class=\"alert alert-danger\" role=\"alert\">\n        No Results Found!\n      </div>\n  <app-subscribeslider></app-subscribeslider>\n\n</ion-content>\n");

/***/ }),

/***/ "ct+p":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../shared/shared.module */ "PCNd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home-routing.module */ "A3+G");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./home.page */ "zpKS");
/* harmony import */ var ngx_stars__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ngx-stars */ "t10x");
/* harmony import */ var ng2_search_filter__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ng2-search-filter */ "cZdB");










let HomePageModule = class HomePageModule {
};
HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__["SharedModule"],
            ngx_stars__WEBPACK_IMPORTED_MODULE_8__["NgxStarsModule"],
            _home_routing_module__WEBPACK_IMPORTED_MODULE_6__["HomePageRoutingModule"],
            ng2_search_filter__WEBPACK_IMPORTED_MODULE_9__["Ng2SearchPipeModule"]
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_7__["HomePage"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], HomePageModule);



/***/ }),

/***/ "f6od":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-segment {\n  background-color: transparent;\n  box-shadow: 0 2px 3px 0 rgba(0, 0, 0, 0.1);\n  border-radius: 0;\n  margin-top: 10px;\n}\nion-segment ion-segment-button {\n  text-transform: capitalize;\n  min-height: 40px !important;\n  border-radius: 0;\n  color: #000;\n  background-color: transparent;\n}\nion-segment ion-segment-button.segment-button-checked {\n  --indicator-color: transparent !important;\n  --indicator-color-checked: transparent !important;\n  background: transparent;\n  margin-bottom: 0;\n  --indicator-box-shadow:none !important;\n  border-bottom: 2px solid #CDAA64;\n  border-radius: 0;\n  --border-radius: 0;\n  color: var(--ion-color-white);\n  --color-checked: var(--ion-color-white)!important;\n  font-weight: 500;\n}\nion-item {\n  border-radius: 8px;\n  margin-bottom: 15px;\n  --padding-start: 0px;\n  --inner-padding-end: 0px;\n}\nion-item ion-thumbnail {\n  width: 90px;\n  height: 100%;\n  margin: 0px;\n  position: relative;\n}\nion-item ion-thumbnail a {\n  display: block;\n  height: 100%;\n}\nion-item ion-thumbnail a img {\n  height: 90px;\n  object-fit: cover;\n}\nion-item ion-thumbnail [heart] {\n  position: absolute;\n  left: 10px;\n  top: 10px;\n  width: 27px;\n  height: 27px;\n  background: rgba(255, 255, 255, 0.72);\n  border-radius: 50%;\n  text-align: center;\n  line-height: 34px;\n  font-size: 16px;\n  color: #c1c1c1;\n}\nion-item ion-thumbnail [heart][filled] {\n  color: var(--ion-color-orange);\n}\nion-item ion-label {\n  white-space: normal;\n  margin-right: 0px;\n  padding-left: 10px;\n  margin: 0;\n}\nion-item ion-label h2 {\n  margin: 0px;\n  padding-right: 5px;\n  font-size: 14px;\n  color: var(--ion-color-black3);\n  font-weight: 600;\n}\nion-item ion-label h2 a {\n  text-decoration: none;\n  color: var(--ion-color-black3);\n}\nion-item ion-label h2 a:hover {\n  color: #CDAA64;\n}\nion-item ion-label p {\n  margin-top: 5px;\n  padding-right: 5px;\n  line-height: 1.25;\n  font-size: 12px;\n  display: flex;\n}\nion-item ion-label p img {\n  height: 16px;\n  min-width: 14px;\n  margin-right: 5px;\n}\nion-item ion-label p[address] {\n  color: var(--ion-color-black4);\n}\nion-item ion-label p[address] ion-icon {\n  font-size: 13px;\n  position: relative;\n  top: 2px;\n  color: #CDAA64;\n}\nion-item ion-label p[category] {\n  align-items: center;\n  color: var(--ion-color-grey4);\n}\nion-item ion-label p[category] a {\n  text-decoration: none;\n}\nion-item ion-label p[category] a span {\n  background-color: #8c2828;\n  color: #fff;\n  display: block;\n  padding: 2px 5px 3px;\n  font-size: 11px;\n  margin-right: 2px;\n  transition: all 0.3s;\n}\nion-item ion-label p[category] a:hover span {\n  background-color: #000;\n}\nion-item ion-label p[category] .liststar {\n  background-color: transparent;\n  padding: 0;\n  margin-left: auto;\n}\nion-item ion-label p[category] .liststar ion-icon {\n  color: #FFA619;\n  font-size: 13px;\n  padding: 0px 1px;\n}\nion-item [salary-apply] {\n  margin-top: 5px;\n}\nion-item [salary-apply] ion-col {\n  padding: 0px;\n}\nion-item [salary-apply] ion-badge {\n  margin-top: 5px;\n  background: var(--ion-color-ltblue);\n  color: var(--ion-color-primary);\n  padding: 4px 10px;\n  font-size: 12px;\n  font-weight: 500;\n  border-radius: 30px;\n}\nion-item [salary-apply] ion-button {\n  margin-bottom: 0px;\n  font-size: 11px;\n  margin-right: 0px;\n  float: right;\n  --background: var(--ion-color-bggradient);\n  text-transform: capitalize;\n  --border-radius: 30px 0px 0px 30px;\n}\n.filtericon {\n  font-size: 32px;\n  border: 1px solid #ececec;\n  padding: 7px 12px;\n  position: relative;\n  top: 12px;\n  border-radius: 6px;\n  color: #8c2828;\n}\n.filtericon.md {\n  top: 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsNkJBQUE7RUFDQSwwQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7QUFDRjtBQUFFO0VBQ0UsMEJBQUE7RUFDQywyQkFBQTtFQUNDLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLDZCQUFBO0FBRU47QUFETTtFQUNFLHlDQUFBO0VBQ0EsaURBQUE7RUFDQSx1QkFBQTtFQUNBLGdCQUFBO0VBQ0Esc0NBQUE7RUFDQSxnQ0FBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSw2QkFBQTtFQUNBLGlEQUFBO0VBQ0EsZ0JBQUE7QUFHUjtBQUVBO0VBQ0Usa0JBQUE7RUFDQSxtQkFBQTtFQUNBLG9CQUFBO0VBQ0Esd0JBQUE7QUFDRjtBQUFFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7QUFFSjtBQURJO0VBQ0UsY0FBQTtFQUNBLFlBQUE7QUFHTjtBQUZNO0VBQ0UsWUFBQTtFQUNBLGlCQUFBO0FBSVI7QUFESTtFQUNFLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFNBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHFDQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFHTjtBQUZNO0VBQ0UsOEJBQUE7QUFJUjtBQUFFO0VBQ0UsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtBQUVKO0FBREk7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsOEJBQUE7RUFDQSxnQkFBQTtBQUdOO0FBRk07RUFDRSxxQkFBQTtFQUNBLDhCQUFBO0FBSVI7QUFIUTtFQUNFLGNBQUE7QUFLVjtBQURJO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsYUFBQTtBQUdOO0FBRk07RUFDRSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FBSVI7QUFGTTtFQUNFLDhCQUFBO0FBSVI7QUFIUTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxjQUFBO0FBS1Y7QUFGTTtFQUNFLG1CQUFBO0VBQ0EsNkJBQUE7QUFJUjtBQUhRO0VBQ0UscUJBQUE7QUFLVjtBQUpVO0VBQ0UseUJBQUE7RUFDQSxXQUFBO0VBQ0EsY0FBQTtFQUNBLG9CQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7QUFNWjtBQUhZO0VBQ0Usc0JBQUE7QUFLZDtBQUNRO0VBRUUsNkJBQUE7RUFDQSxVQUFBO0VBQ0EsaUJBQUE7QUFBVjtBQUNVO0VBQ0UsY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQUNaO0FBS0U7RUFDRSxlQUFBO0FBSEo7QUFJSTtFQUNFLFlBQUE7QUFGTjtBQUlJO0VBQ0UsZUFBQTtFQUNBLG1DQUFBO0VBQ0EsK0JBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FBRk47QUFJSTtFQUNFLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLHlDQUFBO0VBQ0EsMEJBQUE7RUFDQSxrQ0FBQTtBQUZOO0FBT0E7RUFDRSxlQUFBO0VBQ0EseUJBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtBQUpGO0FBT0E7RUFFRSxRQUFBO0FBTEYiLCJmaWxlIjoiaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tc2VnbWVudCB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgYm94LXNoYWRvdzogMCAycHggM3B4IDAgcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG4gIGJvcmRlci1yYWRpdXM6IDA7XHJcbiAgbWFyZ2luLXRvcDogMTBweDtcclxuICBpb24tc2VnbWVudC1idXR0b257XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogY2FwaXRhbGl6ZTtcclxuXHQgICAgbWluLWhlaWdodDogNDBweCFpbXBvcnRhbnQ7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDA7XHJcbiAgICAgIGNvbG9yOiAjMDAwO1xyXG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgJi5zZWdtZW50LWJ1dHRvbi1jaGVja2Vke1xyXG4gICAgICAgIC0taW5kaWNhdG9yLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG4gICAgICAgIC0taW5kaWNhdG9yLWNvbG9yLWNoZWNrZWQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMDtcclxuICAgICAgICAtLWluZGljYXRvci1ib3gtc2hhZG93Om5vbmUgIWltcG9ydGFudDtcclxuICAgICAgICBib3JkZXItYm90dG9tOiAycHggc29saWQgI0NEQUE2NDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAwO1xyXG4gICAgICAgIC0tYm9yZGVyLXJhZGl1czogMDtcclxuICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgICAgICAtLWNvbG9yLWNoZWNrZWQ6IHZhcigtLWlvbi1jb2xvci13aGl0ZSkhaW1wb3J0YW50O1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgIH1cclxuICB9XHJcbn1cclxuXHJcbmlvbi1pdGVtIHtcclxuICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxuICAtLXBhZGRpbmctc3RhcnQ6IDBweDtcclxuICAtLWlubmVyLXBhZGRpbmctZW5kOiAwcHg7XHJcbiAgaW9uLXRodW1ibmFpbCB7XHJcbiAgICB3aWR0aDogOTBweDtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIG1hcmdpbjogMHB4O1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgYXtcclxuICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgaW1ne1xyXG4gICAgICAgIGhlaWdodDogOTBweDtcclxuICAgICAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgW2hlYXJ0XSB7XHJcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgbGVmdDogMTBweDtcclxuICAgICAgdG9wOiAxMHB4O1xyXG4gICAgICB3aWR0aDogMjdweDtcclxuICAgICAgaGVpZ2h0OiAyN3B4O1xyXG4gICAgICBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNzIpO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgbGluZS1oZWlnaHQ6IDM0cHg7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgY29sb3I6ICNjMWMxYzE7XHJcbiAgICAgICZbZmlsbGVkXSB7XHJcbiAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1vcmFuZ2UpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIGlvbi1sYWJlbCB7XHJcbiAgICB3aGl0ZS1zcGFjZTogbm9ybWFsO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAwcHg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgICBoMiB7XHJcbiAgICAgIG1hcmdpbjogMHB4O1xyXG4gICAgICBwYWRkaW5nLXJpZ2h0OiA1cHg7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1ibGFjazMpO1xyXG4gICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICBhe1xyXG4gICAgICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWJsYWNrMyk7XHJcbiAgICAgICAgJjpob3ZlcntcclxuICAgICAgICAgIGNvbG9yOiAjQ0RBQTY0O1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcCB7XHJcbiAgICAgIG1hcmdpbi10b3A6IDVweDtcclxuICAgICAgcGFkZGluZy1yaWdodDogNXB4O1xyXG4gICAgICBsaW5lLWhlaWdodDogMS4yNTtcclxuICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICBpbWcge1xyXG4gICAgICAgIGhlaWdodDogMTZweDtcclxuICAgICAgICBtaW4td2lkdGg6IDE0cHg7XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiA1cHg7XHJcbiAgICAgIH1cclxuICAgICAgJlthZGRyZXNzXSB7XHJcbiAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1ibGFjazQpO1xyXG4gICAgICAgIGlvbi1pY29ue1xyXG4gICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgICAgdG9wOiAycHg7XHJcbiAgICAgICAgICBjb2xvcjogI0NEQUE2NDtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgJltjYXRlZ29yeV0ge1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1ncmV5NCk7XHJcbiAgICAgICAgYXtcclxuICAgICAgICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgICAgICAgIHNwYW57XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICM4YzI4Mjg7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgICAgICAgcGFkZGluZzogMnB4IDVweCAzcHg7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTFweDtcclxuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAycHg7XHJcbiAgICAgICAgICAgIHRyYW5zaXRpb246IGFsbCAwLjNzO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgJjpob3ZlcntcclxuICAgICAgICAgICAgc3BhbntcclxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAwO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmxpc3RzdGFyXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjp0cmFuc3BhcmVudDtcclxuICAgICAgICAgIHBhZGRpbmc6MDtcclxuICAgICAgICAgIG1hcmdpbi1sZWZ0OiBhdXRvO1xyXG4gICAgICAgICAgaW9uLWljb257XHJcbiAgICAgICAgICAgIGNvbG9yOiAjRkZBNjE5O1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDBweCAxcHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIFtzYWxhcnktYXBwbHldIHtcclxuICAgIG1hcmdpbi10b3A6IDVweDtcclxuICAgIGlvbi1jb2wge1xyXG4gICAgICBwYWRkaW5nOiAwcHg7XHJcbiAgICB9XHJcbiAgICBpb24tYmFkZ2Uge1xyXG4gICAgICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1sdGJsdWUpO1xyXG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgICBwYWRkaW5nOiA0cHggMTBweDtcclxuICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gICAgfVxyXG4gICAgaW9uLWJ1dHRvbiB7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IDBweDtcclxuICAgICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgICBtYXJnaW4tcmlnaHQ6IDBweDtcclxuICAgICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1iZ2dyYWRpZW50KTtcclxuICAgICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XHJcbiAgICAgIC0tYm9yZGVyLXJhZGl1czogMzBweCAwcHggMHB4IDMwcHg7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG4uZmlsdGVyaWNvbiB7XHJcbiAgZm9udC1zaXplOiAzMnB4O1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNlY2VjZWM7XHJcbiAgcGFkZGluZzogN3B4IDEycHg7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHRvcDogMTJweDtcclxuICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgY29sb3I6ICM4YzI4Mjg7XHJcbn1cclxuXHJcbi5maWx0ZXJpY29uLm1kXHJcbntcclxuICB0b3A6IDhweDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "zpKS":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./home.page.html */ "WcN3");
/* harmony import */ var _home_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./home.page.scss */ "f6od");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../config */ "Vx+w");
/* harmony import */ var _services_user_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/user/user.service */ "CFL1");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _services_event_event_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../services/event/event.service */ "gcxx");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _filter_filter_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../filter/filter.page */ "H1wQ");










let HomePage = class HomePage {
    constructor(modalController, events1, router, userService, ref, activatedRoute) {
        this.modalController = modalController;
        this.events1 = events1;
        this.router = router;
        this.userService = userService;
        this.ref = ref;
        this.activatedRoute = activatedRoute;
        this.cname = [];
        this.win = window;
        this.errors = ['', null, undefined];
        this.is_submit = false;
        this.IMAGES_URL = _config__WEBPACK_IMPORTED_MODULE_4__["config"].IMAGES_URL;
        this.is_loaded = false;
        this.content = [];
        this.mdata = [];
        this.page_number = 0;
        this.fpage_number = 0;
        this.is_more_records = true;
        this.is_more_records_v = false;
        this.allowedMimes = _config__WEBPACK_IMPORTED_MODULE_4__["config"].IMAGE_EXTENSIONS;
        this.movielist = 'latest';
        this.cbox = [
            { id: 1, testName: "The Latest", checked: false },
            { id: 2, testName: "The Archive", checked: false },
            { id: 3, testName: "The Greatest", checked: false },
            { id: 4, testName: "The Laughable", checked: false }
        ];
    }
    ionViewDidEnter() {
        this.allcategories = [];
    }
    presentModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _filter_filter_page__WEBPACK_IMPORTED_MODULE_9__["FilterPage"],
                cssClass: 'filtermodal',
                componentProps: {
                    filters: {
                        rate: this.ratings,
                        cbox: this.cbox,
                        categories: this.allcategories,
                    }
                }
            });
            modal.onDidDismiss().then((detail) => {
                console.log('detail');
                console.log(detail);
                if (this.errors.indexOf(detail.data) == -1) {
                    if (detail.data.reset == '1') {
                        // this.scrollToTop();
                        var self = this;
                        setTimeout(function () {
                            self.fpage_number = 0;
                            self.is_loaded = false;
                            self.is_more_records = true;
                            self.is_more_records_v = false;
                            self.ratings = [];
                            self.allcategories = [];
                            self.content = [];
                            self.viewdata(false, "");
                        }, 500);
                    }
                    if (detail.data.applied == '1') {
                        let cat_name = [];
                        this.ratings = detail.data.rating;
                        this.allcategories = detail.data.categories;
                        this.allcategories = detail.data.categories;
                        this.allcategories.forEach(function (value, key) {
                            cat_name.push(value);
                        });
                        this.cname = cat_name;
                        console.log(this.cname);
                        //      this.allcategories.forEach(item => {
                        //   this.cat_name = item.testName;
                        // });
                        // this.scrollToTop();
                        var self = this;
                        setTimeout(function () {
                            self.fpage_number = 0;
                            self.is_loaded = false;
                            self.is_more_records = false;
                            self.is_more_records_v = true;
                            self.content = [];
                            self.getfdata(false, "");
                        }, 500);
                    }
                }
            });
            return yield modal.present();
        });
    }
    scrollToTop() {
        var self = this;
        setTimeout(function () {
            self.contents.scrollToTop(300);
        }, 100);
    }
    ngOnInit() {
        this.viewdata(false, "");
    }
    viewdata(isFirstLoad, event) {
        // this.userService.presentLoading();
        this.userService.postData({ page_no: this.page_number }, 'view_allmovies').subscribe((result) => {
            this.userService.stopLoading();
            if (this.errors.indexOf(result.result) == -1) {
                this.is_loaded = true;
                this.mdata = result.result;
                for (let i = 0; i < this.mdata.length; i++) {
                    this.content.push(this.mdata[i]);
                }
                console.log(this.content.length);
                console.log(result.total);
                if (this.content.length == result.total) {
                    this.is_more_records = false;
                }
                if (isFirstLoad)
                    event.target.complete();
                this.page_number++;
            }
            else {
                this.userService.presentToast('Error while fetch results! Please try after some time.', 'danger');
            }
        }, err => {
            this.is_loaded = true;
            this.userService.stopLoading();
            this.userService.presentToast('Unable to fetch results, Please try again', 'danger');
        });
    }
    doInfinite(event) {
        this.viewdata(true, event);
    }
    doInfinite1(event) {
        this.getfdata(true, event);
    }
    getfdata(isFirstLoad, event) {
        this.userService.presentLoading();
        this.userService.postData({ rate: this.ratings, cats_name: this.cname, page_no: this.fpage_number }, 'view_filtersmovies').subscribe((result) => {
            this.userService.stopLoading();
            if (this.errors.indexOf(result.result) == -1) {
                this.is_loaded = true;
                //  this.content = result.result;
                // this.is_more_records_v = false;
                //  console.log(this.content.length);
                this.mdata = result.result;
                for (let i = 0; i < this.mdata.length; i++) {
                    this.content.push(this.mdata[i]);
                }
                console.log(this.content.length);
                console.log(result.ftotal);
                if (this.content.length == result.ftotal) {
                    this.is_more_records_v = false;
                }
                if (isFirstLoad)
                    event.target.complete();
                this.fpage_number++;
            }
            else {
                this.userService.presentToast('No results found! Please try after some time.', 'danger');
            }
        }, err => {
            this.is_loaded = true;
            this.userService.stopLoading();
            this.userService.presentToast('Unable to fetch results, Please try again', 'danger');
        });
    }
};
HomePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["ModalController"] },
    { type: _services_event_event_service__WEBPACK_IMPORTED_MODULE_7__["EventService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _services_user_user_service__WEBPACK_IMPORTED_MODULE_5__["UserService"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ChangeDetectorRef"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"] }
];
HomePage.propDecorators = {
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['mySlider',] }],
    contents: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['contents', { static: true },] }]
};
HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-home',
        template: _raw_loader_home_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_home_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], HomePage);



/***/ })

}]);
//# sourceMappingURL=home-home-module.js.map