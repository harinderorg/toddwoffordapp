(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["realtedarticles-realtedarticles-module"],{

/***/ "AxrD":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/realtedarticles/realtedarticles.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<section class=\"bggrey\">\n  <ion-row class=\"mt-2 mb-4\">\n    <ion-col size=\"12\" class=\"no-padding ion-no-margin\">\n      <h2 class=\"heading\">Related Articles</h2>\n      <ion-slides slidercat pager=\"false\" #mySlider [options]=\"slideOpts\">\n        <ion-slide>\n          <div sliderbox>\n            <a routerLink=\"#\">\n              <span>\n                <img src=\"assets/images/movie.png\" alt=\"\" />\n              </span>\n              <div class=\"contentbox\">\n                <h3>Acasa, My Home <span>(2019)</span></h3>\n                <div class=\"mt-2\" category>\n                  <span class=\"liststar\">\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star-outline\"></ion-icon>\n                  </span>\n                </div>\n              </div>\n            </a>\n          </div>\n        </ion-slide>\n\n        <ion-slide>\n          <div sliderbox>\n            <a routerLink=\"#\">\n              <span>\n                <img src=\"assets/images/movie1.png\" alt=\"\" />\n              </span>\n              <div class=\"contentbox\">\n                <h3>Trolls World Tour <span>(2019)</span></h3>\n                <div class=\"mt-2\" category>\n                  <span class=\"liststar\">\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star-outline\"></ion-icon>\n                  </span>\n                </div>\n              </div>\n            </a>\n          </div>\n        </ion-slide>\n\n        <ion-slide>\n          <div sliderbox>\n            <a routerLink=\"#\">\n              <span>\n                <img src=\"assets/images/movie2.png\" alt=\"\" />\n              </span>\n              <div class=\"contentbox\">\n                <h3>Gloria Bell <span>(2019)</span></h3>\n                <div class=\"mt-2\" category>\n                  <span class=\"liststar\">\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star-outline\"></ion-icon>\n                  </span>\n                </div>\n              </div>\n            </a>\n          </div>\n        </ion-slide>\n\n        <ion-slide>\n          <div sliderbox>\n            <a routerLink=\"#\">\n              <span>\n                <img src=\"assets/images/movie1.png\" alt=\"\" />\n              </span>\n              <div class=\"contentbox\">\n                <h3>Parasite <span>(2019)</span></h3>\n                <div class=\"mt-2\" category>\n                  <span class=\"liststar\">\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star-outline\"></ion-icon>\n                  </span>\n                </div>\n              </div>\n            </a>\n          </div>\n        </ion-slide>\n\n        <ion-slide>\n          <div sliderbox>\n            <a routerLink=\"#\">\n              <span>\n                <img src=\"assets/images/movie2.png\" alt=\"\" />\n              </span>\n              <div class=\"contentbox\">\n                <h3>Gloria Bell <span>(2019)</span></h3>\n                <div class=\"mt-2\" category>\n                  <span class=\"liststar\">\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star\"></ion-icon>\n                    <ion-icon name=\"star-outline\"></ion-icon>\n                  </span>\n                </div>\n              </div>\n            </a>\n          </div>\n        </ion-slide>\n\n      </ion-slides>\n      <!-- <ion-button class=\"backBtn\" (click)=\"swipeNext()\"><ion-icon name=\"chevron-forward-outline\"></ion-icon></ion-button>\n      <ion-button class=\"nextBtn\" (click)=\"swipePrev()\"><ion-icon name=\"chevron-back-outline\"></ion-icon></ion-button> -->\n    </ion-col>\n  </ion-row>\n</section>\n");

/***/ }),

/***/ "FKw7":
/*!***********************************************************!*\
  !*** ./src/app/realtedarticles/realtedarticles.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("[sliderbox] span {\n  width: 100%;\n  height: auto;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  border: transparent;\n  border-radius: 6px;\n  background-color: #fff;\n}\n[sliderbox] span img {\n  width: 100%;\n  height: 108px;\n  object-fit: cover;\n}\n[sliderbox] a {\n  border: 1px solid #dedede;\n  display: block;\n  padding-bottom: 8px;\n}\n[sliderbox] h3 {\n  margin-bottom: 0;\n  font-size: 14px;\n  padding-top: 5px;\n  color: #565656;\n}\n[sliderbox] h3 span {\n  border: none;\n  font-size: 12px;\n  background-color: transparent;\n  color: #8c2828;\n}\n[category] {\n  align-items: center;\n}\n[category] .liststar {\n  background-color: transparent;\n  padding: 0;\n  border: none;\n  margin-left: auto;\n}\n[category] .liststar ion-icon {\n  color: #FFA619;\n  font-size: 13px;\n  padding: 0px 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXHJlYWx0ZWRhcnRpY2xlcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0FBQUo7QUFDSTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EsaUJBQUE7QUFDTjtBQUVFO0VBQ0UseUJBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7QUFBSjtBQUVFO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FBQUo7QUFDSTtFQUNFLFlBQUE7RUFDQSxlQUFBO0VBQ0EsNkJBQUE7RUFDQSxjQUFBO0FBQ047QUFJQTtFQUNFLG1CQUFBO0FBREY7QUFFRTtFQUVFLDZCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtBQURKO0FBRUk7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBQU4iLCJmaWxlIjoicmVhbHRlZGFydGljbGVzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIltzbGlkZXJib3hde1xyXG4gIHNwYW57XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogYXV0bztcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBib3JkZXI6IHRyYW5zcGFyZW50O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcclxuICAgIGltZ3tcclxuICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgIGhlaWdodDogMTA4cHg7XHJcbiAgICAgIG9iamVjdC1maXQ6IGNvdmVyO1xyXG4gICAgfVxyXG4gIH1cclxuICBhe1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2RlZGVkZTtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDhweDtcclxuICB9XHJcbiAgaDN7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAwO1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgcGFkZGluZy10b3A6IDVweDtcclxuICAgIGNvbG9yOiAjNTY1NjU2O1xyXG4gICAgc3BhbntcclxuICAgICAgYm9yZGVyOiBub25lO1xyXG4gICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gICAgICBjb2xvcjogIzhjMjgyODtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbltjYXRlZ29yeV0ge1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgLmxpc3RzdGFyXHJcbiAge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjp0cmFuc3BhcmVudDtcclxuICAgIHBhZGRpbmc6MDtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICAgIG1hcmdpbi1sZWZ0OiBhdXRvO1xyXG4gICAgaW9uLWljb257XHJcbiAgICAgIGNvbG9yOiAjRkZBNjE5O1xyXG4gICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgIHBhZGRpbmc6IDBweCAxcHg7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "f3ly":
/*!*********************************************************!*\
  !*** ./src/app/realtedarticles/realtedarticles.page.ts ***!
  \*********************************************************/
/*! exports provided: RealtedarticlesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RealtedarticlesPage", function() { return RealtedarticlesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_realtedarticles_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./realtedarticles.page.html */ "AxrD");
/* harmony import */ var _realtedarticles_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./realtedarticles.page.scss */ "FKw7");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let RealtedarticlesPage = class RealtedarticlesPage {
    constructor() {
        this.slideOpts = {
            initialSlide: 3,
            spaceBetween: 5,
            margin: 0,
            autoplay: true,
            slidesPerView: 3,
            speed: 600,
            breakpoints: {
                320: {
                    slidesPerView: 3,
                },
                400: {
                    slidesPerView: 3,
                },
                600: {
                    slidesPerView: 3,
                },
                768: {
                    slidesPerView: 3,
                },
                1024: {
                    slidesPerView: 3,
                },
                1200: {
                    slidesPerView: 3,
                },
            }
        };
    }
    ngOnInit() {
    }
    swipeNext() {
        this.slides.slideNext();
    }
    swipePrev() {
        this.slides.slidePrev();
    }
};
RealtedarticlesPage.ctorParameters = () => [];
RealtedarticlesPage.propDecorators = {
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['mySlider',] }]
};
RealtedarticlesPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-realtedarticles',
        template: _raw_loader_realtedarticles_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_realtedarticles_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], RealtedarticlesPage);



/***/ }),

/***/ "h7cF":
/*!*******************************************************************!*\
  !*** ./src/app/realtedarticles/realtedarticles-routing.module.ts ***!
  \*******************************************************************/
/*! exports provided: RealtedarticlesPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RealtedarticlesPageRoutingModule", function() { return RealtedarticlesPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _realtedarticles_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./realtedarticles.page */ "f3ly");




const routes = [
    {
        path: '',
        component: _realtedarticles_page__WEBPACK_IMPORTED_MODULE_3__["RealtedarticlesPage"]
    }
];
let RealtedarticlesPageRoutingModule = class RealtedarticlesPageRoutingModule {
};
RealtedarticlesPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], RealtedarticlesPageRoutingModule);



/***/ }),

/***/ "mhWI":
/*!***********************************************************!*\
  !*** ./src/app/realtedarticles/realtedarticles.module.ts ***!
  \***********************************************************/
/*! exports provided: RealtedarticlesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RealtedarticlesPageModule", function() { return RealtedarticlesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _realtedarticles_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./realtedarticles-routing.module */ "h7cF");
/* harmony import */ var _realtedarticles_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./realtedarticles.page */ "f3ly");







let RealtedarticlesPageModule = class RealtedarticlesPageModule {
};
RealtedarticlesPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _realtedarticles_routing_module__WEBPACK_IMPORTED_MODULE_5__["RealtedarticlesPageRoutingModule"]
        ],
        declarations: [_realtedarticles_page__WEBPACK_IMPORTED_MODULE_6__["RealtedarticlesPage"]]
    })
], RealtedarticlesPageModule);



/***/ })

}]);
//# sourceMappingURL=realtedarticles-realtedarticles-module.js.map