(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["contact-contact-module"],{

/***/ "BjQp":
/*!*******************************************!*\
  !*** ./src/app/contact/contact.module.ts ***!
  \*******************************************/
/*! exports provided: ContactPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactPageModule", function() { return ContactPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _contact_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./contact-routing.module */ "Yuog");
/* harmony import */ var _contact_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./contact.page */ "Ds8B");







let ContactPageModule = class ContactPageModule {
};
ContactPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _contact_routing_module__WEBPACK_IMPORTED_MODULE_5__["ContactPageRoutingModule"]
        ],
        declarations: [_contact_page__WEBPACK_IMPORTED_MODULE_6__["ContactPage"]]
    })
], ContactPageModule);



/***/ }),

/***/ "Ds8B":
/*!*****************************************!*\
  !*** ./src/app/contact/contact.page.ts ***!
  \*****************************************/
/*! exports provided: ContactPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactPage", function() { return ContactPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_contact_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./contact.page.html */ "qbrv");
/* harmony import */ var _contact_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./contact.page.scss */ "xWG2");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../config */ "Vx+w");
/* harmony import */ var _services_event_event_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/event/event.service */ "gcxx");
/* harmony import */ var _services_user_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../services/user/user.service */ "CFL1");








let ContactPage = class ContactPage {
    constructor(events1, userService, router, activatedRoute) {
        this.events1 = events1;
        this.userService = userService;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.errors = ['', null, undefined];
        this.is_loaded = false;
        this.IMAGES_URL = _config__WEBPACK_IMPORTED_MODULE_5__["config"].IMAGES_URL;
        this.viewdata();
    }
    ngOnInit() {
    }
    viewdata() {
        this.userService.presentLoading();
        this.userService.postData({ id: 1 }, 'view_contactdetails').subscribe((result) => {
            this.userService.stopLoading();
            if (this.errors.indexOf(result.result) == -1) {
                this.is_loaded = true;
                this.content = result.result;
                console.log(this.content);
            }
            else {
                this.userService.presentToast('Error while fetch results! Please try after some time.', 'danger');
            }
        }, err => {
            this.is_loaded = true;
            this.userService.stopLoading();
            this.userService.presentToast('Unable to fetch results, Please try again', 'danger');
        });
    }
};
ContactPage.ctorParameters = () => [
    { type: _services_event_event_service__WEBPACK_IMPORTED_MODULE_6__["EventService"] },
    { type: _services_user_user_service__WEBPACK_IMPORTED_MODULE_7__["UserService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] }
];
ContactPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-contact',
        template: _raw_loader_contact_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_contact_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ContactPage);



/***/ }),

/***/ "Yuog":
/*!***************************************************!*\
  !*** ./src/app/contact/contact-routing.module.ts ***!
  \***************************************************/
/*! exports provided: ContactPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactPageRoutingModule", function() { return ContactPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _contact_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./contact.page */ "Ds8B");




const routes = [
    {
        path: '',
        component: _contact_page__WEBPACK_IMPORTED_MODULE_3__["ContactPage"]
    }
];
let ContactPageRoutingModule = class ContactPageRoutingModule {
};
ContactPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ContactPageRoutingModule);



/***/ }),

/***/ "qbrv":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/contact/contact.page.html ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"py-2\" lines=\"none\">\n    <ion-menu-button slot=\"start\">\n      <ion-icon name=\"menu-outline\"></ion-icon>\n    </ion-menu-button>\n    <ion-title>Contact</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid class=\"h-100\">\n    <ion-row class=\"h-100 ion-align-items-center\">\n      <ion-col class=\"subbox\">\n        <h1>Contact</h1>\n        <p [innerHTML]=\"content?.description\" class=\"linkcolor\"></p>\n        <!-- <p>So, let’s say there’s a review you’re just dying to see.  Or, you want to drop a line about the page and whatnot.  Or…maybe you want to schedule an American Tail moment where we both look up at the same full moon.  We can make any or all these things happen, just email me at:\n        </p>\n\n        <p><a routerLink=\"#\">toddwofford@gmail.com</a></p>\n\n        <p>Alternately, you can send me a message on Facebook:</p>\n\n        <p><a routerLink=\"#\">@toddwoffordmovies</a></p>\n\n        <p>Whatever the case may be, I think you’re all just plain adorable.</p>\n\n        <p class=\"mb-0\">–Todd</p> -->\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n");

/***/ }),

/***/ "xWG2":
/*!*******************************************!*\
  !*** ./src/app/contact/contact.page.scss ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("h1 {\n  font-size: 22px;\n  margin-bottom: 15px;\n}\n\nion-button {\n  --border-radius: 6px;\n}\n\nion-item {\n  --padding-start:0px;\n  --min-height: 30px;\n  --inner-padding-end: 0;\n  border: 1px solid #ececec;\n  border-radius: 6px;\n}\n\nion-item ion-icon {\n  position: relative;\n  left: 13px;\n  color: #8c2828;\n  font-size: 20px;\n}\n\nion-item ion-input {\n  --padding-top: 8px;\n  --padding-bottom: 8px;\n  --padding-end: 0;\n  --padding-start: 25px;\n}\n\n.subbox {\n  padding: 20px;\n  border: 1px solid #f1f1f1;\n  margin: 10px;\n  border-radius: 6px;\n}\n\n.subicon {\n  text-align: center;\n  margin: 0 auto;\n  display: block;\n  border-radius: 100px;\n  padding: 17px;\n  font-size: 50px;\n  margin-bottom: 14px;\n  border: 1px solid #ececec;\n  background-color: #8c2828;\n  color: #fff;\n}\n\np {\n  margin-bottom: 15px;\n  line-height: 24px;\n  font-size: 14px;\n  color: #565656;\n}\n\na {\n  color: #8c2828 !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGNvbnRhY3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZUFBQTtFQUNBLG1CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxvQkFBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUNFO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7QUFDSjs7QUFFRTtFQUNFLGtCQUFBO0VBQ0EscUJBQUE7RUFDQSxnQkFBQTtFQUNBLHFCQUFBO0FBQUo7O0FBS0E7RUFFRSxhQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUFIRjs7QUFPQTtFQUVFLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGNBQUE7RUFDQSxvQkFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtFQUNBLHlCQUFBO0VBQ0EsV0FBQTtBQUxGOztBQVFBO0VBRUUsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FBTkY7O0FBU0E7RUFDSSx5QkFBQTtBQU5KIiwiZmlsZSI6ImNvbnRhY3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaDF7XHJcbiAgZm9udC1zaXplOiAyMnB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbn1cclxuXHJcbmlvbi1idXR0b257XHJcbiAgLS1ib3JkZXItcmFkaXVzOiA2cHg7XHJcbn1cclxuXHJcbmlvbi1pdGVte1xyXG4gIC0tcGFkZGluZy1zdGFydDowcHg7XHJcbiAgLS1taW4taGVpZ2h0OiAzMHB4O1xyXG4gIC0taW5uZXItcGFkZGluZy1lbmQ6IDA7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2VjZWNlYztcclxuICBib3JkZXItcmFkaXVzOiA2cHg7XHJcblxyXG4gIGlvbi1pY29ue1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgbGVmdDogMTNweDtcclxuICAgIGNvbG9yOiAjOGMyODI4O1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gIH1cclxuXHJcbiAgaW9uLWlucHV0e1xyXG4gICAgLS1wYWRkaW5nLXRvcDogOHB4O1xyXG4gICAgLS1wYWRkaW5nLWJvdHRvbTogOHB4O1xyXG4gICAgLS1wYWRkaW5nLWVuZDogMDtcclxuICAgIC0tcGFkZGluZy1zdGFydDogMjVweDtcclxuICB9XHJcbn1cclxuXHJcblxyXG4uc3ViYm94XHJcbntcclxuICBwYWRkaW5nOiAyMHB4O1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNmMWYxZjE7XHJcbiAgbWFyZ2luOiAxMHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDZweDtcclxufVxyXG5cclxuXHJcbi5zdWJpY29uXHJcbntcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgbWFyZ2luOiAwIGF1dG87XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgYm9yZGVyLXJhZGl1czogMTAwcHg7XHJcbiAgcGFkZGluZzogMTdweDtcclxuICBmb250LXNpemU6IDUwcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTRweDtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjZWNlY2VjO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICM4YzI4Mjg7XHJcbiAgY29sb3I6ICNmZmY7XHJcbn1cclxuXHJcbnBcclxue1xyXG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG4gIGNvbG9yOiAjNTY1NjU2O1xyXG59XHJcblxyXG5hIHtcclxuICAgIGNvbG9yOiAjOGMyODI4ICFpbXBvcnRhbnQ7XHJcbn0iXX0= */");

/***/ })

}]);
//# sourceMappingURL=contact-contact-module.js.map