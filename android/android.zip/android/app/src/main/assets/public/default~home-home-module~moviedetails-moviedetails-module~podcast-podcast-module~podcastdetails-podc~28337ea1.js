(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~home-home-module~moviedetails-moviedetails-module~podcast-podcast-module~podcastdetails-podc~28337ea1"],{

/***/ "3odR":
/*!***********************************************************!*\
  !*** ./src/app/subscribeslider/subscribeslider.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzdWJzY3JpYmVzbGlkZXIucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "Ul1x":
/*!*********************************************************!*\
  !*** ./src/app/subscribeslider/subscribeslider.page.ts ***!
  \*********************************************************/
/*! exports provided: SubscribesliderPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SubscribesliderPage", function() { return SubscribesliderPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_subscribeslider_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./subscribeslider.page.html */ "ZWIu");
/* harmony import */ var _subscribeslider_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./subscribeslider.page.scss */ "3odR");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _services_event_event_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/event/event.service */ "gcxx");
/* harmony import */ var _services_user_user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/user/user.service */ "CFL1");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @capacitor/core */ "gcOT");








const { Browser } = _capacitor_core__WEBPACK_IMPORTED_MODULE_7__["Plugins"];
let SubscribesliderPage = class SubscribesliderPage {
    constructor(events1, userService, router, activatedRoute) {
        this.events1 = events1;
        this.userService = userService;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.errors = ['', null, undefined];
        this.is_loaded = false;
        this.slideOpts = {
            initialSlide: 1,
            spaceBetween: 2,
            margin: 0,
            autoplay: true,
            slidesPerView: 3,
            speed: 600,
            breakpoints: {
                320: {
                    slidesPerView: 4,
                },
                400: {
                    slidesPerView: 4,
                },
                600: {
                    slidesPerView: 4,
                },
                768: {
                    slidesPerView: 4,
                },
                1024: {
                    slidesPerView: 4,
                },
                1200: {
                    slidesPerView: 4,
                },
            }
        };
        this.viewpodcastsetting();
    }
    ngOnInit() {
    }
    swipeNext() {
        this.slides.slideNext();
    }
    swipePrev() {
        this.slides.slidePrev();
    }
    openWithInAppBrowser(url) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // const url = 'http://capacitor.ionicframework.com/';
            yield Browser.open({ 'url': url });
        });
    }
    viewpodcastsetting() {
        this.userService.postData({ id: 1 }, 'view_allpodcastsettingdata').subscribe((result) => {
            this.userService.stopLoading();
            if (this.errors.indexOf(result.result) == -1) {
                this.is_loaded = true;
                this.pcontent = result.result;
                console.log(this.pcontent);
            }
            else {
                this.userService.presentToast('Error while fetch results! Please try after some time.', 'danger');
            }
        }, err => {
            this.is_loaded = true;
            this.userService.stopLoading();
            this.userService.presentToast('Unable to fetch results, Please try again', 'danger');
        });
    }
};
SubscribesliderPage.ctorParameters = () => [
    { type: _services_event_event_service__WEBPACK_IMPORTED_MODULE_5__["EventService"] },
    { type: _services_user_user_service__WEBPACK_IMPORTED_MODULE_6__["UserService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] }
];
SubscribesliderPage.propDecorators = {
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['mySlider',] }]
};
SubscribesliderPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-subscribeslider',
        template: _raw_loader_subscribeslider_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_subscribeslider_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SubscribesliderPage);



/***/ }),

/***/ "ZWIu":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/subscribeslider/subscribeslider.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<section class=\"bggrey\">\n  <ion-row class=\"mt-2 mb-4\">\n    <ion-col size=\"12\" class=\"no-padding ion-no-margin\">\n      <h2 class=\"heading\">Subscribe to Podcast</h2>\n      <ion-slides slidercat pager=\"false\" #mySlider [options]=\"slideOpts\">\n        <ion-slide (click)=\"openWithInAppBrowser(pcontent?.apple_podcast)\">\n          <div sliderbox>\n              <span>\n                <svg version=\"1.1\" x=\"0px\" y=\"0px\"\n                viewBox=\"0 0 512 512\" style=\"enable-background:new 0 0 512 512;\" xml:space=\"preserve\">\n              <path style=\"fill:#DD86F2;\" d=\"M407,512H105C47.103,512,0,464.897,0,407V105C0,47.103,47.103,0,105,0h302\n              c57.897,0,105,47.103,105,105v302C512,464.897,464.897,512,407,512z\"/>\n              <path style=\"fill:#CD67E5;\" d=\"M407,0H256v512h151c57.897,0,105-47.103,105-105V105C512,47.103,464.897,0,407,0z\"/>\n              <path style=\"fill:#FFFFFF;\" d=\"M308.558,340.537l-9.273,74.185C297.408,429.734,284.646,441,269.517,441h-27.033\n              c-15.13,0-27.892-11.266-29.768-26.279l-9.273-74.185C199.49,308.923,224.14,281,256,281l0,0c-24.813,0-45-20.187-45-45\n              s20.187-45,45-45s45,20.187,45,45s-20.187,45-45,45l0,0C287.86,281,312.51,308.923,308.558,340.537z M256,161\n              c-46.869,0-85,38.131-85,85c0,16.893,4.974,32.637,13.505,45.883c-6.132,10.42-9.908,22.057-11.076,34.072\n              C153.368,305.245,141,277.042,141,246c0-63.411,51.589-115,115-115s115,51.589,115,115c0,31.042-12.368,59.245-32.428,79.956\n              c-1.168-12.016-4.945-23.652-11.076-34.072C336.026,278.637,341,262.893,341,246C341,199.131,302.869,161,256,161z M330.838,404.168\n              l4.617-36.938C374.901,341.289,401,296.639,401,246c0-79.953-65.047-145-145-145s-145,65.047-145,145\n              c0,50.639,26.099,95.289,65.545,121.23l4.617,36.938C122.004,376.063,81,315.734,81,246c0-96.495,78.505-175,175-175\n              s175,78.505,175,175C431,315.734,389.996,376.063,330.838,404.168z\"/>\n              <g>\n              <path style=\"fill:#F2F2F2;\" d=\"M256,281L256,281v160h13.517c15.13,0,27.892-11.266,29.768-26.279l9.273-74.185\n                C312.51,308.923,287.86,281,256,281z\"/>\n              <path style=\"fill:#F2F2F2;\" d=\"M301,236c0-24.813-20.187-45-45-45v90C280.813,281,301,260.813,301,236z\"/>\n              <path style=\"fill:#F2F2F2;\" d=\"M256,71v30c79.953,0,145,65.047,145,145c0,50.639-26.099,95.289-65.545,121.23l-4.617,36.938\n                C389.996,376.063,431,315.734,431,246C431,149.505,352.495,71,256,71z\"/>\n              <path style=\"fill:#F2F2F2;\" d=\"M338.572,325.956C358.632,305.245,371,277.042,371,246c0-63.411-51.589-115-115-115v30\n                c46.869,0,85,38.131,85,85c0,16.893-4.974,32.637-13.505,45.883C333.627,302.304,337.404,313.94,338.572,325.956z\"/>\n              </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n                </svg>\n              </span>\n              <h3>Apple Podcasts</h3>\n            \n          </div>\n        </ion-slide>\n\n        <ion-slide (click)=\"openWithInAppBrowser(pcontent?.google_podcast)\">\n          <div sliderbox>\n              <span>\n                <img src=\"assets/images/googlepod.png\" alt=\"\" />\n              </span>\n              <h3>Google Podcasts</h3>\n        \n          </div>\n        </ion-slide>\n\n        <ion-slide (click)=\"openWithInAppBrowser(pcontent?.android)\">\n          <div sliderbox>\n              <span>\n                <svg version=\"1.1\" x=\"0px\" y=\"0px\"\n                viewBox=\"0 0 512.12 512.12\" style=\"enable-background:new 0 0 512.12 512.12;\" xml:space=\"preserve\">\n              <g>\n              <path style=\"fill:#4CAF50;\" d=\"M74.727,170.787c-17.673,0-32,14.327-32,32V352.12c0,17.673,14.327,32,32,32s32-14.327,32-32\n                V202.787C106.727,185.114,92.4,170.787,74.727,170.787z\"/>\n              <path style=\"fill:#4CAF50;\" d=\"M437.393,170.787c-17.673,0-32,14.327-32,32V352.12c0,17.673,14.327,32,32,32s32-14.327,32-32\n                V202.787C469.393,185.114,455.067,170.787,437.393,170.787z\"/>\n              <path style=\"fill:#4CAF50;\" d=\"M373.393,170.787H138.727c-5.891,0-10.667,4.776-10.667,10.667V352.12\n                c-0.005,25.348,17.831,47.197,42.667,52.267v75.733c0,17.673,14.327,32,32,32s32-14.327,32-32v-74.667h42.667v74.667\n                c0,17.673,14.327,32,32,32s32-14.327,32-32v-75.733c24.836-5.07,42.672-26.919,42.667-52.267V181.454\n                C384.06,175.563,379.284,170.787,373.393,170.787z\"/>\n              <path style=\"fill:#4CAF50;\" d=\"M333.607,44.323l26.005-25.984c4.237-4.093,4.354-10.845,0.262-15.083\n                c-4.093-4.237-10.845-4.354-15.083-0.262c-0.089,0.086-0.176,0.173-0.262,0.262L314.236,33.55\n                c-37.102-16.117-79.229-16.117-116.331,0L167.612,3.235c-4.237-4.093-10.99-3.975-15.083,0.262c-3.992,4.134-3.992,10.687,0,14.82\n                l25.984,26.005c-31.677,20.96-50.649,56.481-50.453,94.464c0,5.891,4.776,10.667,10.667,10.667h234.667\n                c5.891,0,10.667-4.776,10.667-10.667C384.256,100.804,365.284,65.283,333.607,44.323z\"/>\n            </g>\n            <g>\n              <circle style=\"fill:#FAFAFA;\" cx=\"202.727\" cy=\"96.12\" r=\"10.667\"/>\n              <circle style=\"fill:#FAFAFA;\" cx=\"309.393\" cy=\"96.12\" r=\"10.667\"/>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            </svg>\n              </span>\n              <h3>Android</h3>\n          </div>\n        </ion-slide>\n\n        <ion-slide (click)=\"openWithInAppBrowser(pcontent?.email)\">\n          <div sliderbox>\n              <span>\n              <svg version=\"1.1\" x=\"0px\" y=\"0px\"\n              viewBox=\"0 0 512 512\" style=\"enable-background:new 0 0 512 512;\" xml:space=\"preserve\">\n          <rect x=\"64\" y=\"64\" style=\"fill:#ECEFF1;\" width=\"384\" height=\"384\"/>\n          <polygon style=\"fill:#CFD8DC;\" points=\"256,296.384 448,448 448,148.672 \"/>\n          <path style=\"fill:#F44336;\" d=\"M464,64h-16L256,215.616L64,64H48C21.504,64,0,85.504,0,112v288c0,26.496,21.504,48,48,48h16V148.672\n            l192,147.68L448,148.64V448h16c26.496,0,48-21.504,48-48V112C512,85.504,490.496,64,464,64z\"/>\n          <g>\n          </g>\n          <g>\n          </g>\n          <g>\n          </g>\n          <g>\n          </g>\n          <g>\n          </g>\n          <g>\n          </g>\n          <g>\n          </g>\n          <g>\n          </g>\n          <g>\n          </g>\n          <g>\n          </g>\n          <g>\n          </g>\n          <g>\n          </g>\n          <g>\n          </g>\n          <g>\n          </g>\n          <g>\n          </g>\n          </svg>\n              </span>\n              <h3>By Email</h3>\n            \n          </div>\n        </ion-slide>\n\n        <ion-slide (click)=\"openWithInAppBrowser(pcontent?.rss)\">\n          <div sliderbox>\n              <span>\n                <svg version=\"1.1\" x=\"0px\" y=\"0px\"\n                viewBox=\"0 0 455.731 455.731\" style=\"enable-background:new 0 0 455.731 455.731;\" xml:space=\"preserve\">\n            <g>\n              <rect x=\"0\" y=\"0\" style=\"fill:#F78422;\" width=\"455.731\" height=\"455.731\"/>\n              <g>\n                <path style=\"fill:#FFFFFF;\" d=\"M296.208,159.16C234.445,97.397,152.266,63.382,64.81,63.382v64.348\n                  c70.268,0,136.288,27.321,185.898,76.931c49.609,49.61,76.931,115.63,76.931,185.898h64.348\n                  C391.986,303.103,357.971,220.923,296.208,159.16z\"/>\n                <path style=\"fill:#FFFFFF;\" d=\"M64.143,172.273v64.348c84.881,0,153.938,69.056,153.938,153.939h64.348\n                  C282.429,270.196,184.507,172.273,64.143,172.273z\"/>\n                <circle style=\"fill:#FFFFFF;\" cx=\"109.833\" cy=\"346.26\" r=\"46.088\"/>\n              </g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            <g>\n            </g>\n            </svg>\n              </span>\n              <h3>RSS</h3>\n           \n          </div>\n        </ion-slide>\n      </ion-slides>\n      <!-- <ion-button class=\"backBtn\" (click)=\"swipeNext()\"><ion-icon name=\"chevron-forward-outline\"></ion-icon></ion-button>\n      <ion-button class=\"nextBtn\" (click)=\"swipePrev()\"><ion-icon name=\"chevron-back-outline\"></ion-icon></ion-button> -->\n    </ion-col>\n  </ion-row>\n</section>\n");

/***/ })

}]);
//# sourceMappingURL=default~home-home-module~moviedetails-moviedetails-module~podcast-podcast-module~podcastdetails-podc~28337ea1.js.map