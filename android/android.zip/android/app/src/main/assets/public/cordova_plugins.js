
  cordova.define('cordova/plugin_list', function(require, exports, module) {
    module.exports = [
      {
          "id": "branch-cordova-sdk.Branch",
          "file": "plugins/branch-cordova-sdk/src/index.js",
          "pluginId": "branch-cordova-sdk",
        "clobbers": [
          "Branch"
        ]
        }
    ];
    module.exports.metadata =
    // TOP OF METADATA
    {
      "branch-cordova-sdk": "4.2.1"
    };
    // BOTTOM OF METADATA
    });
    