(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["moviedetails-moviedetails-module"],{

/***/ "BHd+":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/moviedetails/moviedetails.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"py-2\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/home\"><ion-icon name=\"arrow-back-outline\"></ion-icon></ion-back-button>\n    </ion-buttons>\n\n    <ion-title>Movie Details</ion-title> \n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"movietop\"> \n    <!-- <img src=\"assets/images/post.jpg\" alt=\"\" class=\"img-fluid\" /> -->\n    <img *ngIf=\"errors.indexOf(content?.image) >= 0\" src=\"assets/images/dummy.png\" class=\"img-fluid\"/> \n<img *ngIf=\"errors.indexOf(content?.image) == -1\" src=\"{{ IMAGES_URL+'/'+content?.image }}\" class=\"img-fluid\"/>\n    <ion-card-subtitle>{{content?.category}}</ion-card-subtitle>\n    <span category>\n      <span class=\"liststar\" *ngIf=\"errors.indexOf(content?.rating) == -1\">\n         <ngx-stars  [size]='1' [readonly]=\"true\" [initialStars]=\"content.rating\" [maxStars]=\"5\" [color]=\"'#f90'\"></ngx-stars>\n      </span>\n    </span>\n  </div>\n  <ion-card-header class=\"p-3 pb0\">\n    <ion-card-title>{{content?.title}}</ion-card-title>\n    <p address class=\"pb-0 mt-1 mb-0\"><span><ion-icon name=\"time-outline\"></ion-icon> {{dates}}</span></p>\n  </ion-card-header>\n\n  <div class=\"p-3\" [innerHTML]=\"content?.description\">\n  \n  </div>\n\n  <ion-fab horizontal=\"end\" vertical=\"bottom\" slot=\"fixed\">\n    <ion-fab-button color=\"primary\" (click)=\"shares()\">\n      <ion-icon name=\"share-social-outline\"></ion-icon>\n    </ion-fab-button>\n   <!--  <ion-fab-list side=\"start\">\n      <ion-fab-button color=\"medium\" size=\"small\">\n        <a routerLink=\"#\"><ion-icon name=\"logo-facebook\"></ion-icon></a>\n      </ion-fab-button>\n      <ion-fab-button color=\"medium\" size=\"small\">\n        <a routerLink=\"#\"><ion-icon name=\"logo-google\"></ion-icon></a>\n      </ion-fab-button>\n      <ion-fab-button color=\"medium\" size=\"small\">\n        <a routerLink=\"#\"><ion-icon name=\"logo-twitter\"></ion-icon></a>\n      </ion-fab-button>\n      <ion-fab-button color=\"medium\" size=\"small\">\n        <a routerLink=\"#\"><ion-icon name=\"logo-youtube\"></ion-icon></a>\n      </ion-fab-button>\n      <ion-fab-button color=\"medium\" size=\"small\">\n        <a routerLink=\"#\"><ion-icon name=\"logo-rss\"></ion-icon></a>\n      </ion-fab-button>\n    </ion-fab-list> -->\n  </ion-fab>\n<section class=\"bggrey\">\n  <ion-row class=\"mt-2 mb-4\">\n    <ion-col size=\"12\" class=\"no-padding ion-no-margin\">\n      <h2 class=\"heading\">Related Articles</h2>\n      <ion-slides slidercat pager=\"false\" #mySlider [options]=\"slideOpts\">\n        <ion-slide *ngFor=\"let data of rcontent\">\n          <div sliderbox>\n            <a routerLink=\"/moviedetails/{{data?.id}}\">\n              <span>\n              <img *ngIf=\"errors.indexOf(data.image) >= 0\" src=\"assets/images/dummy.png\"/> \n<img *ngIf=\"errors.indexOf(data.image) == -1\" src=\"{{ IMAGES_URL+'/'+data.image }}\"/>\n              </span>\n              <div class=\"contentbox\">\n                <h3><span>{{data?.title | slice:0:40}}</span></h3>\n                <div class=\"mt-2\" category>\n                  <span class=\"rliststar\">\n                   <ngx-stars  [size]='1' [readonly]=\"true\" [initialStars]=\"data?.rating\" [maxStars]=\"5\" [color]=\"'#f90'\"></ngx-stars>\n                  </span>\n                </div>\n              </div>\n            </a>\n          </div>\n        </ion-slide>\n<div style=\"text-align: center;background: #ccc;padding: 15px;\" *ngIf=\"rcontent == '' && is_loaded == true\" class=\"alert alert-danger\" role=\"alert\">\n        No Articles Found!\n      </div>\n        \n         </ion-slides>\n      \n    </ion-col>\n  </ion-row>\n</section>\n  <!-- <app-realtedarticles></app-realtedarticles> -->\n</ion-content>\n");

/***/ }),

/***/ "K3K8":
/*!*****************************************************!*\
  !*** ./src/app/moviedetails/moviedetails.module.ts ***!
  \*****************************************************/
/*! exports provided: MoviedetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MoviedetailsPageModule", function() { return MoviedetailsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../shared/shared.module */ "PCNd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _moviedetails_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./moviedetails-routing.module */ "gYq6");
/* harmony import */ var _moviedetails_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./moviedetails.page */ "wEBp");
/* harmony import */ var ngx_stars__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ngx-stars */ "t10x");









let MoviedetailsPageModule = class MoviedetailsPageModule {
};
MoviedetailsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_4__["SharedModule"],
            ngx_stars__WEBPACK_IMPORTED_MODULE_8__["NgxStarsModule"],
            _moviedetails_routing_module__WEBPACK_IMPORTED_MODULE_6__["MoviedetailsPageRoutingModule"]
        ],
        declarations: [_moviedetails_page__WEBPACK_IMPORTED_MODULE_7__["MoviedetailsPage"]]
    })
], MoviedetailsPageModule);



/***/ }),

/***/ "M4Yi":
/*!*****************************************************!*\
  !*** ./src/app/moviedetails/moviedetails.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("[address] {\n  color: var(--ion-color-black4);\n}\n[address] span {\n  font-size: 14px;\n}\n[address] ion-icon {\n  font-size: 18px;\n  position: relative;\n  top: 4px;\n  color: #CDAA64;\n}\n[category] {\n  align-items: center;\n  color: var(--ion-color-grey4);\n  position: absolute;\n  bottom: 5px;\n  z-index: 9;\n  display: block;\n  right: 5px;\n}\n[category] .liststar {\n  background-color: transparent;\n  padding: 0;\n  margin-left: auto;\n}\n[category] .liststar ion-icon {\n  color: #FFA619;\n  font-size: 17px;\n  padding: 0px 4px;\n}\n.pb0 {\n  padding-bottom: 0 !important;\n}\np {\n  margin-bottom: 15px;\n  line-height: 24px;\n  font-size: 14px;\n  color: #565656;\n}\n.movietop {\n  position: relative;\n}\n.movietop img {\n  height: 250px;\n  width: 100%;\n  object-fit: cover;\n}\n.movietop::after {\n  position: absolute;\n  content: \"\";\n  bottom: 0;\n  left: 0;\n  background-image: linear-gradient(transparent, rgba(32, 32, 32, 0.83));\n  width: 100%;\n  height: 20%;\n}\n.movietop ion-card-subtitle {\n  position: absolute;\n  top: 8px;\n  right: 0;\n  background-color: #8c2828;\n  padding: 4px 13px 5px;\n  color: #fff;\n  border-radius: 5px 0 0 5px;\n}\nion-fab-button {\n  width: 40px;\n  height: 40px;\n}\nion-fab-button ion-icon {\n  font-size: 22px;\n}\nion-fab-button a {\n  color: #fff;\n}\nion-fab-list ion-fab-button {\n  width: 35px;\n  height: 35px;\n  position: relative;\n  top: -8px;\n}\nion-fab-list ion-fab-button ion-icon {\n  font-size: 18px;\n  position: relative;\n  top: 2px;\n}\n[sliderbox] span {\n  width: 100%;\n  height: auto;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  border: transparent;\n  border-radius: 6px;\n  background-color: #fff;\n}\n[sliderbox] span img {\n  width: 100%;\n  height: 108px;\n  object-fit: cover;\n}\n[sliderbox] a {\n  border: 1px solid #dedede;\n  display: block;\n  padding-bottom: 3px;\n}\n[sliderbox] h3 {\n  margin-bottom: 0;\n  font-size: 14px;\n  padding-top: 5px;\n  color: #565656;\n  height: 35px;\n}\n[sliderbox] h3 span {\n  border: none;\n  font-size: 12px;\n  background-color: transparent;\n  color: #8c2828;\n}\n[category] {\n  align-items: center;\n  right: 0;\n  left: 0;\n  position: relative;\n}\n[category] .rliststar {\n  background-color: transparent;\n  padding: 0;\n  border: none;\n  margin-left: auto;\n}\n[category] .rliststar ion-icon {\n  color: #FFA619;\n  font-size: 13px;\n  padding: 0px 1px;\n}\n::ng-deep .star.zero-star {\n  display: none !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXG1vdmllZGV0YWlscy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSw4QkFBQTtBQUNGO0FBQUU7RUFDRSxlQUFBO0FBRUo7QUFBRTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxjQUFBO0FBRUo7QUFFQTtFQUNFLG1CQUFBO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0VBQ0EsY0FBQTtFQUNBLFVBQUE7QUFDRjtBQUNFO0VBRUUsNkJBQUE7RUFDQSxVQUFBO0VBQ0EsaUJBQUE7QUFBSjtBQUNJO0VBQ0UsY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQUNOO0FBSUE7RUFFRSw0QkFBQTtBQUZGO0FBS0E7RUFFRSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFIRjtBQU1BO0VBRUUsa0JBQUE7QUFKRjtBQUtFO0VBQ0UsYUFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtBQUhKO0FBS0U7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsT0FBQTtFQUNBLHNFQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7QUFISjtBQUtFO0VBQ0Usa0JBQUE7RUFDQSxRQUFBO0VBQ0EsUUFBQTtFQUNBLHlCQUFBO0VBQ0EscUJBQUE7RUFDQSxXQUFBO0VBQ0EsMEJBQUE7QUFISjtBQVFBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUFMRjtBQU1FO0VBQ0UsZUFBQTtBQUpKO0FBTUU7RUFDRSxXQUFBO0FBSko7QUFVRTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0FBUEo7QUFRSTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7QUFOTjtBQVlFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtBQVRKO0FBVUk7RUFDRSxXQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0FBUk47QUFXRTtFQUNFLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0FBVEo7QUFXRTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUFUSjtBQVVJO0VBQ0UsWUFBQTtFQUNBLGVBQUE7RUFDQSw2QkFBQTtFQUNBLGNBQUE7QUFSTjtBQWFBO0VBQ0UsbUJBQUE7RUFDQyxRQUFBO0VBQ0MsT0FBQTtFQUNFLGtCQUFBO0FBVk47QUFXRTtFQUVFLDZCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFFQSxpQkFBQTtBQVhKO0FBYUk7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBWE47QUFrQkU7RUFFRSx3QkFBQTtBQWhCSiIsImZpbGUiOiJtb3ZpZWRldGFpbHMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiW2FkZHJlc3NdIHtcclxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWJsYWNrNCk7XHJcbiAgc3BhbntcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICB9XHJcbiAgaW9uLWljb257XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICB0b3A6IDRweDtcclxuICAgIGNvbG9yOiAjQ0RBQTY0O1xyXG4gIH1cclxufVxyXG5cclxuW2NhdGVnb3J5XSB7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWdyZXk0KTtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgYm90dG9tOiA1cHg7XHJcbiAgei1pbmRleDogOTtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICByaWdodDogNXB4O1xyXG5cclxuICAubGlzdHN0YXJcclxuICB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOnRyYW5zcGFyZW50O1xyXG4gICAgcGFkZGluZzowO1xyXG4gICAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgICBpb24taWNvbntcclxuICAgICAgY29sb3I6ICNGRkE2MTk7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTdweDtcclxuICAgICAgcGFkZGluZzogMHB4IDRweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbi5wYjBcclxue1xyXG4gIHBhZGRpbmctYm90dG9tOiAwICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbnBcclxue1xyXG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG4gIGNvbG9yOiAjNTY1NjU2O1xyXG59XHJcblxyXG4ubW92aWV0b3Bcclxue1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBpbWd7XHJcbiAgICBoZWlnaHQ6IDI1MHB4O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICB9XHJcbiAgJjo6YWZ0ZXJ7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBjb250ZW50OiBcIlwiO1xyXG4gICAgYm90dG9tOiAwO1xyXG4gICAgbGVmdDogMDtcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0cmFuc3BhcmVudCwgcmdiKDMyIDMyIDMyIC8gODMlKSk7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMjAlO1xyXG4gIH1cclxuICBpb24tY2FyZC1zdWJ0aXRsZXtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogOHB4O1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjOGMyODI4O1xyXG4gICAgcGFkZGluZzogNHB4IDEzcHggNXB4O1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHggMCAwIDVweDtcclxuICB9XHJcblxyXG59XHJcblxyXG5pb24tZmFiLWJ1dHRvbntcclxuICB3aWR0aDogNDBweDtcclxuICBoZWlnaHQ6IDQwcHg7XHJcbiAgaW9uLWljb257XHJcbiAgICBmb250LXNpemU6IDIycHg7XHJcbiAgfVxyXG4gIGF7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICB9XHJcblxyXG59XHJcblxyXG5pb24tZmFiLWxpc3Qge1xyXG4gIGlvbi1mYWItYnV0dG9ue1xyXG4gICAgd2lkdGg6IDM1cHg7XHJcbiAgICBoZWlnaHQ6IDM1cHg7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICB0b3A6IC04cHg7XHJcbiAgICBpb24taWNvbntcclxuICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgIHRvcDogMnB4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuW3NsaWRlcmJveF17XHJcbiAgc3BhbntcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiBhdXRvO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGJvcmRlcjogdHJhbnNwYXJlbnQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xyXG4gICAgaW1ne1xyXG4gICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgaGVpZ2h0OiAxMDhweDtcclxuICAgICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZGVkZWRlO1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogM3B4O1xyXG4gIH1cclxuICBoM3tcclxuICAgIG1hcmdpbi1ib3R0b206IDA7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBwYWRkaW5nLXRvcDogNXB4O1xyXG4gICAgY29sb3I6ICM1NjU2NTY7XHJcbiAgICBoZWlnaHQ6IDM1cHg7XHJcbiAgICBzcGFue1xyXG4gICAgICBib3JkZXI6IG5vbmU7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgICAgIGNvbG9yOiAjOGMyODI4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuW2NhdGVnb3J5XSB7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgcmlnaHQ6MDtcclxuICAgIGxlZnQ6MDtcclxuICAgICAgcG9zaXRpb246cmVsYXRpdmU7XHJcbiAgLnJsaXN0c3RhclxyXG4gIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6dHJhbnNwYXJlbnQ7XHJcbiAgICBwYWRkaW5nOjA7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgIFxyXG4gICAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcblxyXG4gICAgaW9uLWljb257XHJcbiAgICAgIGNvbG9yOiAjRkZBNjE5O1xyXG4gICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgIHBhZGRpbmc6IDBweCAxcHg7IFxyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuXHJcbjo6bmctZGVlcHtcclxuICAuc3Rhci56ZXJvLXN0YXIgXHJcbiAge1xyXG4gICAgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50O1xyXG4gIH1cclxufVxyXG4iXX0= */");

/***/ }),

/***/ "gYq6":
/*!*************************************************************!*\
  !*** ./src/app/moviedetails/moviedetails-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: MoviedetailsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MoviedetailsPageRoutingModule", function() { return MoviedetailsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _moviedetails_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./moviedetails.page */ "wEBp");




const routes = [
    {
        path: '',
        component: _moviedetails_page__WEBPACK_IMPORTED_MODULE_3__["MoviedetailsPage"]
    }
];
let MoviedetailsPageRoutingModule = class MoviedetailsPageRoutingModule {
};
MoviedetailsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MoviedetailsPageRoutingModule);



/***/ }),

/***/ "wEBp":
/*!***************************************************!*\
  !*** ./src/app/moviedetails/moviedetails.page.ts ***!
  \***************************************************/
/*! exports provided: MoviedetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MoviedetailsPage", function() { return MoviedetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_moviedetails_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./moviedetails.page.html */ "BHd+");
/* harmony import */ var _moviedetails_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./moviedetails.page.scss */ "M4Yi");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../config */ "Vx+w");
/* harmony import */ var _services_event_event_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/event/event.service */ "gcxx");
/* harmony import */ var _services_user_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../services/user/user.service */ "CFL1");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @capacitor/core */ "gcOT");









const { BranchDeepLinks } = _capacitor_core__WEBPACK_IMPORTED_MODULE_8__["Plugins"];
const { Share } = _capacitor_core__WEBPACK_IMPORTED_MODULE_8__["Plugins"];
let MoviedetailsPage = class MoviedetailsPage {
    constructor(events1, userService, router, activatedRoute) {
        this.events1 = events1;
        this.userService = userService;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.errors = ['', null, undefined];
        this.is_loaded = false;
        this.IMAGES_URL = _config__WEBPACK_IMPORTED_MODULE_5__["config"].IMAGES_URL;
        this.BASE_URL = _config__WEBPACK_IMPORTED_MODULE_5__["config"].BASE_URL;
        this.slideOpts = {
            initialSlide: 3,
            spaceBetween: 5,
            margin: 0,
            autoplay: true,
            slidesPerView: 3,
            speed: 600,
            breakpoints: {
                320: {
                    slidesPerView: 3,
                },
                400: {
                    slidesPerView: 3,
                },
                600: {
                    slidesPerView: 3,
                },
                768: {
                    slidesPerView: 3,
                },
                1024: {
                    slidesPerView: 3,
                },
                1200: {
                    slidesPerView: 3,
                },
            }
        };
        this.id = activatedRoute.snapshot.paramMap.get('id');
        console.log(this.id);
        this.viewdata();
    }
    ngOnInit() {
    }
    swipeNext() {
        this.slides.slideNext();
    }
    swipePrev() {
        this.slides.slidePrev();
    }
    viewdata() {
        this.userService.presentLoading();
        this.userService.postData({ id: this.id }, 'view_moviesdetails').subscribe((result) => {
            this.userService.stopLoading();
            if (this.errors.indexOf(result.result) == -1) {
                this.is_loaded = true;
                this.content = result.result;
                this.dates = result.date;
                console.log(this.content);
                console.log(result.date);
                this.viewrelatedata(this.content.title);
                this.share_message = 'Share this movie with your nearest friends and be the part of ' + this.content.title;
            }
            else {
                this.userService.presentToast('Error while fetch results! Please try after some time.', 'danger');
            }
        }, err => {
            this.is_loaded = true;
            this.userService.stopLoading();
            this.userService.presentToast('Unable to fetch results, Please try again', 'danger');
        });
    }
    viewrelatedata(title) {
        // this.userService.presentLoading();
        this.userService.postData({ title: title, id: this.id }, 'view_relatedmoviesdetails').subscribe((result) => {
            this.userService.stopLoading();
            if (this.errors.indexOf(result.result) == -1) {
                this.is_loaded = true;
                this.rcontent = result.result;
                console.log(this.rcontent);
            }
            else {
                this.userService.presentToast('Error while fetch results! Please try after some time.', 'danger');
            }
        }, err => {
            this.is_loaded = true;
            this.userService.stopLoading();
            this.userService.presentToast('Unable to fetch results, Please try again', 'danger');
        });
    }
    shares() {
        // optional fields
        var analytics = {
            channel: 'facebook',
            feature: 'onboarding',
            campaign: 'content 123 launch',
            stage: 'new user',
            tags: ['one', 'two', 'three']
        };
        // optional fields
        var properties = {
            $desktop_url: 'http://www.google.com/desktop',
            $android_url: 'http://www.google.com/android',
            $ios_url: 'http://www.google.com/ios',
            $ipad_url: 'http://www.google.com/ipad',
            $match_duration: 2000,
            custom_string: 'data',
            custom_integer: Date.now(),
            custom_boolean: true
        };
        var shareText = 'Share ' + this.content.title + ' movie reviews with your nearest friends. Checkout the link:';
        BranchDeepLinks.showShareSheet({ analytics, properties, shareText }).then(function (res) {
            console.log('Response: ' + JSON.stringify(res));
            //   let shareRet =  Share.share({
            //   title: 'ToddWofford Movies',
            //   text: this.share_message,
            //   url: res.url,
            //   dialogTitle: 'Share with buddies'
            // });
        }).catch(function (err) {
            console.log('Error: ' + JSON.stringify(err));
        });
        //  let shareRet = await Share.share({
        //   title: 'ToddWofford Movies',
        //   text: this.share_message,
        //   url: 'https://www.toddwoffordmovies.com/',
        //   dialogTitle: 'Share with buddies'
        // });
    }
};
MoviedetailsPage.ctorParameters = () => [
    { type: _services_event_event_service__WEBPACK_IMPORTED_MODULE_6__["EventService"] },
    { type: _services_user_user_service__WEBPACK_IMPORTED_MODULE_7__["UserService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] }
];
MoviedetailsPage.propDecorators = {
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['mySlider',] }]
};
MoviedetailsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-moviedetails',
        template: _raw_loader_moviedetails_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_moviedetails_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], MoviedetailsPage);



/***/ })

}]);
//# sourceMappingURL=moviedetails-moviedetails-module.js.map